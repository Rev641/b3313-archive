-- name: B3313 Area Display
-- description: \\#ff00ff\\B\\#ff0000\\3\\#5555ff\\3\\#ffff00\\1\\#00ff00\\3\\#ff7700\\ Area Display\n\n\\#ffffff\\This mod displays the proper names of each area every player is in. It's easier to keep track of stars and their locations that way. Names are accurate to their latest version (either 0.7 or 0.9).\n\nMod by \\#2b0013\\Floralys\\#ffffff\\.

areas = {
    [LEVEL_BOB] = {
        [1] = {name = "Crimson Hallway", course = "C1", color = "blue"},
        [2] = {name = "3rd Floor (Beta)", course = "C1", color = "blue"},
        [3] = {name = "athletic", course = "C1", color = "yellow"},
        [4] = {name = "Bowser's Castle", course = "C1", color = "blue"},
        [5] = {name = "Fake Lobby", course = "C1", color = "blue"},
        [6] = {name = "Crescent Castle", course = "C1", color = "blue"},
        [7] = {name = "Goomba Hills", course = "C1", color = "yellow"}
    },
    [LEVEL_WF] = {
        [1] = {name = "Cryptic Hideout", course = "C2", color = "blue"},
        [2] = {name = "Dark Lobby", course = "C2", color = "blue"},
        [3] = {name = "Plexal Basement", course = "C2", color = "blue"},
        [4] = {name = "Plexal Basement", course = "C2", color = "purple"},
        [5] = {name = "Empty Flooded Hallway", course = "C2", color = "purple"},
        [6] = {name = "Lavish Lava Mountain", course = "C2", color = "yellow"},
        [7] = {name = "Lavish Lava Mountain", course = "C2", color = "yellow"}
    },
    [LEVEL_JRB] = {
        [1] = {name = "River Mountain", course = "C3", color = "yellow"},
        [2] = {name = "Big Bob-omb's Fortress", course = "C3", color = "purple"},
        [3] = {name = "Piranha Plant Garden", course = "C3", color = "yellow"},
        [4] = {name = "Minion Base", course = "C3", color = "yellow"},
        [5] = {name = "Piranha's Igloo", course = "C3", color = "yellow"}
    },
    [LEVEL_CCM] = {
        [1] = {name = "Jolly Roger Lagoon", course = "C4", color = "yellow"},
        [2] = {name = "Orange Hall", course = "C4", color = "blue"},
        [3] = {name = "Test Level", course = "C4", color = "yellow"},
        [4] = {name = "Checkerboard 1", course = "C4", color = "purple"},
        [5] = {name = "Holy Yellow Switch Palace", course = "C4", color = "purple"},
        [6] = {name = "Holy Yellow Switch Palace", course = "C4", color = "purple"}
    },
    [LEVEL_BBH] = {
        [1] = {name = "Whomp's Kingdom", course = "C5", color = "yellow"},
        [2] = {name = "Whomp's Prison", course = "C5", color = "yellow"},
        [3] = {name = "Mountain (B-Roll)", course = "C5", color = "green"},
        [4] = {name = "King Whomp's Battle Arena", course = "C5", color = "purple"},
        [5] = {name = "Flower Fields", course = "C5", color = "yellow"},
        [6] = {name = "Vanish Cap under the Moat (Beta)", course = "C5", color = "yellow"}
    },
    [LEVEL_HMC] = {
        [1] = {name = "Hazy Maze Cave", course = "C6", color = "purple"},
        [2] = {name = "Tick Tock Blocks", course = "C6", color = "yellow"},
        [3] = {name = "Midnight Meadow", course = "C6", color = "yellow"},
        [4] = {name = "Lethal Cavern", course = "C6", color = "yellow"},
        [5] = {name = "Lonely Forest Path", course = "C6", color = "red"}, --Unused
        [6] = {name = "Cave City", course = "C6", color = "yellow"},
        [7] = {name = "Click Clock Climb", course = "C6", color = "yellow"}
    },
    [LEVEL_LLL] = {
        [1] = {name = "Blazing Bully Base", course = "C7", color = "yellow"},
        [2] = {name = "Peaceful Sewer Maze", course = "C7", color = "purple"},
        [3] = {name = "Blazing Bully Base", course = "C7", color = "yellow"},
        [4] = {name = "Infernal Tower", course = "C7", color = "yellow"},
        [5] = {name = "Fire Bubble (B-Roll)", course = "C7", color = "yellow"}
    },
    [LEVEL_SSL] = {
        [1] = {name = "Desert Maze", course = "C8", color = "yellow"},
        [2] = {name = "Shifted Sand Land", course = "C8", color = "yellow"},
        [3] = {name = "Scary Sewer Maze", course = "C8", color = "purple"},
        [4] = {name = "Eyerok's Tomb", course = "C8", color = "purple"},
        [5] = {name = "Sandy Skyloft", course = "C8", color = "yellow"},
        [6] = {name = "Scary Sewer Maze", course = "C8", color = "purple"},
        [7] = {name = "Scary Sewer Maze", course = "C8", color = "purple"}
    },
    [LEVEL_DDD] = {
        [1] = {name = "Dark Hallway", course = "C9", color = "green"},
        [2] = {name = "Checkerboard 2", course = "C9", color = "purple"},
        [3] = {name = "Deadly Descent", course = "C9", color = "green"},
        [4] = {name = "Delicious Cake", course = "C9", color = "purple"},
        [5] = {name = "Snow Slide (B-Roll)", course = "C9", color = "yellow"},
        [6] = {name = "Snowman's Land (Beta)", course = "C9", color = "yellow"},
        [7] = {name = "Frosty Highlands", course = "C9", color = "yellow"}
    },
    [LEVEL_SL] = {
        [1] = {name = "Floating Hotel", course = "C10", color = "yellow"},
        [2] = {name = "Haunted Castle Grounds", course = "C10", color = "green"},
        [3] = {name = "Wing Cap by the Rainbow Highway", course = "C10", color = "yellow"},
        [4] = {name = "Tower of the Wing Cap (Beta)", course = "C10", color = "purple"},
        [5] = {name = "Rainbow Ride (Beta)", course = "C10", color = "yellow"},
        [6] = {name = "Vanish Cap within the Plexus", course = "C10", color = "yellow"}
    },
    [LEVEL_WDW] = {
        [1] = {name = "Snow Slide (Shoshinkai)", course = "C11", color = "yellow"},
        [2] = {name = "Snowman's Darkness", course = "C11", color = "green"},
        [3] = {name = "Frosty Highlands", course = "C11", color = "yellow"},
        [4] = {name = "Cool, Cool Mountain (Beta)", course = "C11", color = "yellow"},
        [5] = {name = "Chief Chilly's Ring", course = "C11", color = "purple"},
        [6] = {name = "Cold, Cold Crevasse", course = "C11", color = "yellow"},
        [7] = {name = "Chroma Tundra", course = "C11", color = "yellow"}
    },
    [LEVEL_TTM] = {
        [1] = {name = "Tall, Tall Mountain", course = "C12", color = "yellow"},
        [2] = {name = "Monkey Slide", course = "C12", color = "green"},
        [3] = {name = "Monkey Slide", course = "C12", color = "green"},
        [4] = {name = "Monkey Slide", course = "C12", color = "green"}
    },
    [LEVEL_THI] = {
        [1] = {name = "Castle Grounds", course = "C13", color = "blue"},
        [2] = {name = "Bob-Omb Tower", course = "C13", color = "yellow"},
        [3] = {name = "Creepy Cove", course = "C13", color = "yellow"},
        [4] = {name = "Grassy Highlands", course = "C13", color = "yellow"},
        [5] = {name = "Minion Base", course = "C13", color = "yellow"},
        [6] = {name = "Peach's Cell", course = "C13", color = "green"},
        [7] = {name = "Peach's Cell", course = "C13", color = "green"}
    },
    [LEVEL_TTC] = {
        [1] = {name = "Big Boo's Haunted Forest", course = "C14", color = "yellow"},
        [2] = {name = "Dark Lobby", course = "C14", color = "blue"},
        [3] = {name = "Plexal Lobby", course = "C14", color = "blue"},
        [4] = {name = "Clock Hall", course = "C14", color = "blue"},
        [5] = {name = "Big Boo's Fortress", course = "C14", color = "yellow"},
        [6] = {name = "Plexal Hallway", course = "C14", color = "blue"},
        [7] = {name = "Bowser's Floor / Peach's Floor", course = "C14", color = "blue"}
    },
    [LEVEL_RR] = {
        [1] = {name = "Jolly Roger Bay (Beta)", course = "C15", color = "yellow"},
        [2] = {name = "Wiggler's Forest Fortress", course = "C15", color = "purple"},
        [3] = {name = "Checkerboard 3", course = "C15", color = "purple"},
        [4] = {name = "Bowser's Maze", course = "C15", color = "blue"},
        [5] = {name = "Balcony", course = "C15", color = "green"}
    },
    [LEVEL_PSS] = {
        [1] = {name = "Dark Downtown", course = "Slide", color = "yellow"},
        [2] = {name = "castle2", course = "Slide", color = "yellow"},
        [3] = {name = "Cubic Greens", course = "Slide", color = "yellow"},
        [4] = {name = "Jolly Rotom Bay 2", course = "Slide", color = "red"}, --Unused
        [5] = {name = "Bob-Omb Village", course = "Slide", color = "yellow"},
        [6] = {name = "Dead Village", course = "Slide", color = "purple"},
        [7] = {name = "Plexal Upstairs", course = "Slide", color = "blue"}
    },
    [LEVEL_SA] = {
        [1] = {name = "Dry Town", course = "S2", color = "yellow"},
        [2] = {name = "Wiggler's Forest Fortress", course = "S2", color = "purple"},
        [3] = {name = "Pleasant, Pleasant Falls", course = "S2", color = "yellow"},
        [4] = {name = "Sky-High Pathway", course = "S2", color = "yellow"},
        [6] = {name = "Ruins in the Blood Lake", course = "S2", color = "green"}
    },
    [LEVEL_WMOTR] = {
        [1] = {name = "Water Land (Shoshinkai)", course = "S1", color = "yellow"},
        [2] = {name = "castle1", course = "S1", color = "yellow"},
        [3] = {name = "castle1", course = "S1", color = "yellow"},
        [4] = {name = "Secret Beach", course = "S1", color = "red"}, --Unused
        [5] = {name = "Castle Garden", course = "S1", color = "purple"},
        [6] = {name = "Castle Garden", course = "S1", color = "purple"}
    },
    [LEVEL_ENDING] = {
        [1] = {name = "Flooded Town", course = "S3", color = "yellow"},
        [2] = {name = "Underground Passageway", course = "S3", color = "blue"},
        [6] = {name = "Wet-Dry World (Beta)", course = "S3", color = "yellow"}
    },
    [LEVEL_CASTLE_GROUNDS] = {
        [1] = {name = "Castle Grounds", course = "OW (Grounds)", color = "blue"},
        [2] = {name = "Beta Lobbies C & D", course = "OW (Grounds)", color = "blue"},
        [3] = {name = "Beta Lobby B", course = "OW (Grounds)", color = "blue"},
        [4] = {name = "Beta Lobby A", course = "OW (Grounds)", color = "blue"},
        [5] = {name = "Genesis Basement", course = "OW (Grounds)", color = "blue"},
        [6] = {name = "Bowser Hallway / Bowser's Prison", course = "OW (Grounds)", color = "blue"},
        [7] = {name = "Plexal Upstairs", course = "OW (Grounds)", color = "blue"}
    },
    [LEVEL_CASTLE] = {
        [1] = {name = "Vanilla Lobby", course = "OW (Castle)", color = "blue"},
        [2] = {name = "Vanilla Upstairs", course = "OW (Castle)", color = "blue"},
        [3] = {name = "Vanilla Basement", course = "OW (Castle)", color = "blue"}
    },
    [LEVEL_CASTLE_COURTYARD] = {
        [1] = {name = "Uncanny Courtyard", course = "OW (Courtyard)", color = "blue"},
        [2] = {name = "Forest Maze", course = "OW (Courtyard)", color = "green"},
        [3] = {name = "The Star", course = "OW (Courtyard)", color = "green"},
        [4] = {name = "Purple Upstairs", course = "OW (Courtyard)", color = "blue"},
        [5] = {name = "The Void", course = "OW (Courtyard)", color = "green"},
        [6] = {name = "Uncanny Courtyard", course = "OW (Courtyard)", color = "blue"},
        [7] = {name = "Uncanny Courtyard", course = "OW (Courtyard)", color = "blue"}
    },
    [LEVEL_COTMC] = {
        [1] = {name = "Mountain (B-Roll)", course = "MC", color = "yellow"},
        [2] = {name = "Goomboss Battle", course = "MC", color = "yellow"},
        [3] = {name = "Sinister Clockwork", course = "MC", color = "purple"},
        [4] = {name = "Whomp's Fortress (Beta)", course = "MC", color = "yellow"},
        [5] = {name = "Tall Floating Fortress", course = "MC", color = "yellow"},
        [6] = {name = "Rocky Trek", course = "MC", color = "yellow"}
    },
    [LEVEL_TOTWC] = {
        [1] = {name = "Eel Graveyard", course = "WC", color = "purple"},
        [2] = {name = "Empty Graveyard", course = "WC", color = "red"}, --Unused
        [3] = {name = "Checkerboard 4", course = "WC", color = "purple"},
        [4] = {name = "Plexal Upstairs", course = "WC", color = "blue"},
        [5] = {name = "Silent Hall", course = "WC", color = "blue"},
        [6] = {name = "Nightly Void", course = "WC", color = "green"},
        [7] = {name = "Nightly Void", course = "WC", color = "green"}
    },
    [LEVEL_VCUTM] = {
        [1] = {name = "Battle Fort", course = "VC", color = "yellow"},
        [2] = {name = "Floor 2B", course = "VC", color = "blue"},
        [3] = {name = "Randomized Realm", course = "VC", color = "yellow"},
        [4] = {name = "2nd Floor (Beta)", course = "VC", color = "red"}, --Unused
        [5] = {name = "Bob-Omb Test Field", course = "VC", color = "yellow"},
        [6] = {name = "Big Bob-omb's Fortress", course = "VC", color = "purple"}
    },
    [LEVEL_BITDW] = {
        [1] = {name = "Tiny-Huge Island (Beta)", course = "BC1", color = "yellow"},
        [2] = {name = "Uncanny Courtyard", course = "BC1", color = "blue"},
        [3] = {name = "Creepy Cove", course = "BC1", color = "yellow"},
        [4] = {name = "Sunken Castle", course = "BC1", color = "yellow"},
        [5] = {name = "Mario's Maze", course = "BC1", color = "purple"},
        [6] = {name = "Mario's Maze", course = "BC1", color = "purple"}
    },
    [LEVEL_BITFS] = {
        [1] = {name = "Aquarium Limbo", course = "BC2", color = "yellow"},
        [2] = {name = "Cryptic Hideout", course = "BC2", color = "blue"},
        [3] = {name = "Cryptic Hideout", course = "BC2", color = "purple"},
        [4] = {name = "Cryptic Hideout", course = "BC2", color = "purple"},
        [5] = {name = "Funhouse", course = "BC2", color = "blue"}
    },
    [LEVEL_BITS] = {
        [1] = {name = "Wet-Dry World (Beta)", course = "BC3", color = "yellow"},
        [3] = {name = "Ice-Cold Warzone", course = "BC3", color = "yellow"},
        [4] = {name = "Bob-Omb Battlefield (Beta)", course = "BC3", color = "yellow"}
    },
    [LEVEL_BOWSER_1] = {
        [1] = {name = "Bowser in the Dark World (Shoshinkai)", course = "B1", color = "purple"}
    },
    [LEVEL_BOWSER_2] = {
        [1] = {name = "Bowser's Checkered Madness", course = "B2", color = "purple"},
        [2] = {name = "Bowser in the Bully Battlefield", course = "B2", color = "purple"},
        [3] = {name = "Bowser in the Fire Sea", course = "B2", color = "purple"}
    },
    [LEVEL_BOWSER_3] = {
        [1] = {name = "Eternal Fort (Beta)", course = "B3", color = "purple"},
        [2] = {name = "Crashing Night Sky", course = "B3", color = "green"}
    }
}

--local timer = 0
local function mario_update(m)
    if m.playerIndex ~= 0 then return end
    --timer = timer + 1
    --if timer >= 30 then
        local defaultAreaName = get_level_name(gNetworkPlayers[m.playerIndex].currCourseNum, gNetworkPlayers[m.playerIndex].currLevelNum, gNetworkPlayers[m.playerIndex].currAreaIndex)

        if areas[gNetworkPlayers[m.playerIndex].currLevelNum] ~= nil then
            gPlayerSyncTable[m.playerIndex].location = areas[gNetworkPlayers[m.playerIndex].currLevelNum][gNetworkPlayers[m.playerIndex].currAreaIndex].name
            gPlayerSyncTable[m.playerIndex].course = areas[gNetworkPlayers[m.playerIndex].currLevelNum][gNetworkPlayers[m.playerIndex].currAreaIndex].course
            gPlayerSyncTable[m.playerIndex].color = areas[gNetworkPlayers[m.playerIndex].currLevelNum][gNetworkPlayers[m.playerIndex].currAreaIndex].color
            gPlayerSyncTable[m.playerIndex].area = gNetworkPlayers[m.playerIndex].currAreaIndex
        else
            gPlayerSyncTable[m.playerIndex].location = defaultAreaName
            gPlayerSyncTable[m.playerIndex].course = "???"
            gPlayerSyncTable[m.playerIndex].color = "red"
            gPlayerSyncTable[m.playerIndex].area = "???"
        end

        --timer = 0
    --end
end

local hide_names = false
hook_event(HOOK_ON_MODS_LOADED, function ()
    for i = 0, #gActiveMods, 1 do
        if gActiveMods[i].name:find("Hide and Seek") or gActiveMods[i].name:find("Scavenger Hunt") then
            hide_names = true
        end
    end
end)

local function b3313_area_name_update() --Updates Playerlist
    for i = 0, MAX_PLAYERS - 1 do
        local m = gMarioStates[i]
        local np = gNetworkPlayers[i]
        local defaultAreaName = get_level_name(gNetworkPlayers[m.playerIndex].currCourseNum, gNetworkPlayers[m.playerIndex].currLevelNum, gNetworkPlayers[m.playerIndex].currAreaIndex)
        if not hide_names then
            if areas[gNetworkPlayers[m.playerIndex].currLevelNum] ~= nil then
                gPlayerSyncTable[m.playerIndex].location = areas[gNetworkPlayers[m.playerIndex].currLevelNum][gNetworkPlayers[m.playerIndex].currAreaIndex].name
            else
                gPlayerSyncTable[m.playerIndex].location = defaultAreaName
            end
        else
            gPlayerSyncTable[m.playerIndex].location = " "
        end
        network_player_set_override_location(np, gPlayerSyncTable[m.playerIndex].location)
    end
end

for i = 0, MAX_PLAYERS - 1 do
    gPlayerSyncTable[i].location = "Loading..."
    gPlayerSyncTable[i].course = "???"
    gPlayerSyncTable[i].color = "red"
    gPlayerSyncTable[i].area = "???"
end

-- Checks for Character Select
local charSelectOn = false
hook_event(HOOK_ON_MODS_LOADED, function(m)
    charSelectOn = _G.charSelectExists
end)

local life_icons = {
    [CT_MARIO] = gTextures.mario_head,
    [CT_LUIGI] = gTextures.luigi_head,
    [CT_TOAD] = gTextures.toad_head,
    [CT_WALUIGI] = gTextures.waluigi_head,
    [CT_WARIO] = gTextures.wario_head,
}

---@param text string
---@return nil, number, number, number, number
local function convert_color(text)
    if text:sub(2, 2) ~= "#" then
        return nil
    end
    text = text:sub(3, -2)
    local rstring = text:sub(1, 2) or "ff"
    local gstring = text:sub(3, 4) or "ff"
    local bstring = text:sub(5, 6) or "ff"
    local astring = text:sub(7, 8) or "ff"
    local r = tonumber("0x" .. rstring) or 255
    local g = tonumber("0x" .. gstring) or 255
    local b = tonumber("0x" .. bstring) or 255
    local a = tonumber("0x" .. astring) or 255
    return r, g, b, a
end

---@param text string
---@param get_color boolean|nil
---@return string, string, string, boolean
local function remove_color(text, get_color)
    local start = text:find("\\")
    local next = 1
    while (next ~= nil) and (start ~= nil) do
        start = text:find("\\")
        if start ~= nil then
            next = text:find("\\", start + 1)
            if next == nil then
                next = text:len() + 1
            end

            if get_color then
                local color = text:sub(start, next)
                local render = text:sub(1, start - 1)
                text = text:sub(next + 1)
                return text, color, render
            else
                text = text:sub(1, start - 1) .. text:sub(next + 1)
            end
        end
    end
    return text
end

local function djui_hud_print_text_with_color(text, x, y, scale, red, green, blue, alpha)
    djui_hud_set_color(red or 255, green or 255, blue or 255, alpha or 255)
    local space = 0
    local color = ""
    text, color, render = remove_color(text, true)
    while render ~= nil do
        local r, g, b, a = convert_color(color)
        if alpha then a = alpha end
        djui_hud_print_text(render, x + space, y, scale);
        if r then djui_hud_set_color(r, g, b, a) end
        space = space + djui_hud_measure_text(render) * scale
        text, color, render = remove_color(text, true)
    end
    djui_hud_print_text(text, x + space, y, scale);
end

local TEX_B3313_PLAYERLIST_BACKGROUND_BETA = get_texture_info("b3313_beta_background")
local TEX_B3313_PLAYERLIST_BACKGROUND_VANILLA = get_texture_info("b3313_vanilla_background")
local TEX_B3313_PLAYERLIST_BACKGROUND_PARALLEL = get_texture_info("b3313_parallel_background")
local TEX_B3313_PLAYERLIST_BACKGROUND_NEBULA = get_texture_info("b3313_nebula_background")
local TEX_B3313_PLAYERLIST_BACKGROUND_CRIMSON = get_texture_info("b3313_crimson_background")


local bodyWidth = 1200
local bodyHeight = (16 * 32) + (16 - 1) * 4 + (32 + 16) + 32 + 32
local boarderWidth = 12
local function extended_area_list()
    djui_hud_set_resolution(RESOLUTION_DJUI)
    --local x = djui_hud_get_screen_width()*0.5 - 363 - bodyWidth
    local DateTimeValue = get_date_and_time()
    local x = djui_hud_get_screen_width()*0.5 - bodyWidth*0.5
    local y = djui_hud_get_screen_height()*0.5 - bodyHeight*0.5

    --djui_hud_set_color(0, 0, 0, 200)
    djui_hud_set_color(0, 0, 0, 150)
    djui_hud_render_rect(x, y, bodyWidth, bodyHeight)

    djui_hud_set_color(255, 255, 255, 175)
    if DateTimeValue.hour >= 20 or DateTimeValue.hour < 1 then
        djui_hud_render_texture(TEX_B3313_PLAYERLIST_BACKGROUND_NEBULA, x, y, 9.37, 10.67)
    elseif DateTimeValue.hour >= 1 and DateTimeValue.hour < 5 then
        djui_hud_render_texture(TEX_B3313_PLAYERLIST_BACKGROUND_CRIMSON, x, y, 9.37, 10.67)
    elseif DateTimeValue.hour >= 5 and DateTimeValue.hour < 10 then
        djui_hud_render_texture(TEX_B3313_PLAYERLIST_BACKGROUND_BETA, x, y, 9.37, 10.67)
    elseif DateTimeValue.hour >= 10 and DateTimeValue.hour < 17 then
        djui_hud_render_texture(TEX_B3313_PLAYERLIST_BACKGROUND_VANILLA, x, y, 9.37, 10.67)
    elseif DateTimeValue.hour >= 17 and DateTimeValue.hour < 20 then
        djui_hud_render_texture(TEX_B3313_PLAYERLIST_BACKGROUND_PARALLEL, x, y, 9.37, 10.67)
    end
    
    djui_hud_set_color(0, 0, 0, 140)
    djui_hud_render_rect(x + boarderWidth, y + boarderWidth, bodyWidth - boarderWidth*2, bodyHeight - boarderWidth*2)

    djui_hud_set_font(FONT_HUD)
    djui_hud_set_color(255, 255, 255, 255)
    djui_hud_print_text("PLAYERS", x + bodyWidth*0.475 - djui_hud_measure_text("PLAYERS"), y + 25, 3)

    -- Render Heads
    local x = x + 22
    local y = djui_hud_get_screen_height() * 0.5 - 36 * 8 - 2
    for i = 0, MAX_PLAYERS - 1 do
        local np = gNetworkPlayers[i]
        --djui_chat_message_create(tostring(b)..tostring(np.currCourseNum)..tostring(course))
        if np and np.connected then
            y = y + 36
            
            if i%2 == 0 then
                djui_hud_set_color(32, 32, 32, 128)
            else
                djui_hud_set_color(16, 16, 16, 128)
            end
            djui_hud_render_rect(x, y, bodyWidth - 44, 32)

            djui_hud_set_font(FONT_HUD)
            djui_hud_set_color(255, 255, 255, 255)
            if not charSelectOn then
                djui_hud_render_texture(life_icons[gMarioStates[i].character.type], x, y, 2, 2)
            else
                _G.charSelect.character_render_life_icon(np.localIndex, x, y, 2)
            end

            playerNameColor = {
                r = 127 + network_player_get_override_palette_color_channel(np, CAP, 0) / 2,
                g = 127 + network_player_get_override_palette_color_channel(np, CAP, 1) / 2,
                b = 127 + network_player_get_override_palette_color_channel(np, CAP, 2) / 2
            }

            djui_hud_set_font(FONT_NORMAL)
            djui_hud_print_text_with_color(gNetworkPlayers[i].name, x + 40, y, 1, playerNameColor.r, playerNameColor.g, playerNameColor.b, 255)
            djui_hud_print_text_with_color(gNetworkPlayers[i].name, x + 40, y, 1, 255, 255, 255, 127)

            if np.description then
                djui_hud_print_text_with_color(np.description, (x + 278) - (djui_hud_measure_text((string.gsub(np.description, "\\(.-)\\", "")))/2), y, 1, np.descriptionR, np.descriptionG, np.descriptionB, np.descriptionA)
            end

            if gPlayerSyncTable[i].color == "yellow" then
                djui_hud_set_color(255, 255, 0, 255)
            elseif gPlayerSyncTable[i].color == "green" then
                djui_hud_set_color(0, 255, 0, 255)
            elseif gPlayerSyncTable[i].color == "blue" then
                djui_hud_set_color(0, 255, 255, 255)
            elseif gPlayerSyncTable[i].color == "purple" then
                djui_hud_set_color(255, 0, 255, 255)
            elseif gPlayerSyncTable[i].color == "red" then
                djui_hud_set_color(255, 0, 0, 255)
            end
            if not hide_names then
                --djui_hud_print_text(gPlayerSyncTable[i].location, x + 425, y, 1)
                djui_hud_print_text(gPlayerSyncTable[i].location, ((x + 625) - djui_hud_measure_text((string.gsub(gPlayerSyncTable[i].location, "\\(.-)\\", "")))/2), y, 1)
                --djui_hud_print_text_with_color("("..gPlayerSyncTable[i].course.." - A"..gPlayerSyncTable[i].area..")", x + 825, y, 1, 127, 127, 127, 255)
                local areaID = "("..gPlayerSyncTable[i].course.." - A"..gPlayerSyncTable[i].area..")"
                djui_hud_print_text_with_color(areaID, ((x + 950) - djui_hud_measure_text((string.gsub(areaID, "\\(.-)\\", "")))/2), y, 1, 127, 127, 127, 255)
            else
                djui_hud_print_text_with_color("Kinda pointless to have on the extended display rn, huh?", x + 425, y, 1, 127, 127, 127, 255)
            end

            if np.currActNum then
                currActNum = np.currActNum == 99 and "Done" or np.currActNum ~= 0 and "# "..tostring(np.currActNum) or ""
                printedcurrActNum = currActNum
                djui_hud_print_text_with_color(printedcurrActNum, x + 1160 - djui_hud_measure_text(printedcurrActNum) - 18, y, 1, 0xdc, 0xdc, 0xdc, 255)
            end
        end
    end
end


local extendedAreaList = false
local function on_hud_render()
    --djui_hud_set_resolution(RESOLUTION_N64)
    --djui_hud_set_font(FONT_HUD)
    --djui_hud_set_color(255, 255, 255, 255)

    if extendedAreaList then
        gServerSettings.enablePlayerList = false
        if charSelectOn then
            _G.gServerSettingsCS.enablePlayerList = false
        end
        if djui_attempting_to_open_playerlist() then
            extended_area_list()
        end
    end
    if not extendedAreaList then
        if not charSelectOn then
            gServerSettings.enablePlayerList = true
        else
            gServerSettings.enablePlayerList = false
            _G.gServerSettingsCS.enablePlayerList = true
        end
    end
end

local function blist_command(msg)
    extendedAreaList = not extendedAreaList
    return true
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_UPDATE, b3313_area_name_update)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
--hook_chat_command("blist", "- [\\#ff00ff\\B\\#ff0000\\3\\#5555ff\\3\\#ffff00\\1\\#00ff00\\3\\#ff7700\\ Extended Area Display\\#ffffff\\] [on/off] Toggles whether or not the extended area display is shown to you.", blist_command)
hook_mod_menu_checkbox("Extended Area Display", extendedAreaList, blist_command)