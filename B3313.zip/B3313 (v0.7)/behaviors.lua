-- Star Dust
local check = 0
local modelStar = 0

E_MODEL_STAR_DUST = smlua_model_util_get_id("star_dust_geo")
E_MODEL_STAR_TRANSPARENT = smlua_model_util_get_id("transparent_star_geo")
local function on_interact(m, o, type)
    if gMarioStates[0].playerIndex ~= 0 then return end
    if type == INTERACT_STAR_OR_KEY then
        if get_id_from_behavior(o.behavior) ~= id_bhvBowserKey then
            oBeh = o.oBehParams
            --djui_chat_message_create(tostring(oBeh))
            modelStar = 1
            spawn_sync_object(id_bhvSmoke, E_MODEL_STAR_DUST, o.oPosX, o.oPosY, o.oPosZ, function() end)
            check = 0
            if (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 7) then
                spawn_sync_object(id_bhvStar, E_MODEL_STAR_TRANSPARENT, o.oPosX, o.oPosY, o.oPosZ, function(o) o.oBehParams = oBeh end)
            end
        else modelStar = 0 end
    end
end

hook_event(HOOK_ON_INTERACT, on_interact)

---@param o Object
function wind_init(o)
    o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_ACTIVE_FROM_AFAR)
end
---@param o Object
function wind_loop(o)
    ---@type MarioState
    local m = gMarioStates[0]
    obj_copy_pos(pos, o)
    play_sound(SOUND_AIR_HOWLING_WIND, m.marioObj.header.gfx.cameraToObject)
    -- o.oPosX = gMarioStates[0].pos.x
    -- o.oPosY = gMarioStates[0].pos.y
    -- o.oPosZ = gMarioStates[0].pos.z
    o.oPosX = m.pos.x
    o.oPosY = m.pos.y
    o.oPosZ = m.pos.z
    -- obj_set_pos(o, gMarioStates[0].pos.x, gMarioStates[0].pos.y, gMarioStates[0].pos.z)
end
---@param o Object
function ukiki_init(o)
    o.oInteractionSubtype = INT_SUBTYPE_NPC
    o.oInteractType = INTERACT_TEXT
    o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW)
    bhv_bobomb_buddy_init()
    smlua_anim_util_set_animation(o, "koopa")
    o.oIntangibleTimer = 0
    o.hitboxHeight = 113
    o.hitboxRadius = 65
    o.hitboxDownOffset = 0
    o.oGravity = 2.5
    o.oFriction = 0.8
    o.oBuoyancy = 1.3
    o.oGraphYOffset = o.oGraphYOffset + 35
    timer = 0
end
---@param o Object
function ukiki_loop(o)
    bhv_bobomb_buddy_loop()
    local timer = timer + 1
    ---@type MarioState
    local m = gMarioStates[0]
    if timer == 0 then
        smlua_anim_util_set_animation(o, "koopa")
    end
    if timer == 0x3C then
        smlua_anim_util_set_animation(o, "koopa2")
    end
    if timer == 0x3C + 0x1A then
        smlua_anim_util_set_animation(o, "koopa3")
    end
    if timer == 0x3C + 0x1A + 0x22 then
        timer = 0
    end
    
    object_step()
end
id_bhvSandSoundLoop = hook_behavior(id_bhvSandSoundLoop, OBJ_LIST_LEVEL, true, wind_init, wind_loop, "Sand Ambient Sounds")
id_bhvUkiki = hook_behavior(id_bhvUkiki, OBJ_LIST_LEVEL, true, ukiki_init, ukiki_loop, "ukiki")


function bhv_star_loop(o)
    o.oAnimState = o.oAnimState + 1
    obj_set_billboard(o)
    obj_scale(o, 1.25)
end


function bhv_celebration_star_loop(o)
    if modelStar == 1 then
        obj_set_model_extended(o, E_MODEL_STAR)
        if check < 33 then
            o.oAnimState = o.oAnimState + 1
            check = check + 1
        end
        obj_set_billboard(o)
        obj_scale(o, 0.5 + (0.75 / (34 - check)))
    end
end

function bhv_grand_star_loop(o)
    o.oAnimState = o.oAnimState + 1
    obj_set_billboard(o)
    obj_scale(o, 3)
end

hook_behavior(id_bhvStar, OBJ_LIST_GENACTOR, false, nil, bhv_star_loop)
hook_behavior(id_bhvSpawnedStar, OBJ_LIST_GENACTOR, false, nil, bhv_star_loop)
hook_behavior(id_bhvHiddenStar, OBJ_LIST_GENACTOR, false, nil, bhv_star_loop)
hook_behavior(id_bhvStarSpawnCoordinates, OBJ_LIST_GENACTOR, false, nil, bhv_star_loop)
hook_behavior(id_bhvSpawnedStarNoLevelExit, OBJ_LIST_GENACTOR, false, nil, bhv_star_loop)
hook_behavior(id_bhvCelebrationStar, OBJ_LIST_GENACTOR, false, nil, bhv_celebration_star_loop)
hook_behavior(id_bhvGrandStar, OBJ_LIST_GENACTOR, false, nil, bhv_grand_star_loop)

bhvB3313Peach = hook_behavior(nil, OBJ_LIST_GENACTOR, true, function(o)
    o.oFlags = OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_HOLDABLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    o.oAnimations = gObjectAnimations.peach_seg5_anims_0501C41C
    --o.oFaceAngleYaw = 0
    o.oInteractType = INTERACT_TEXT
    o.oInteractionSubtype = INT_SUBTYPE_NPC
    o.hitboxRadius = 90
    o.hitboxHeight = 150
    o.oOpacity = 255
    cur_obj_init_animation(0)
    --bhv_toad_message_init()
    bhv_bobomb_buddy_init()
end, function(o)
    o.oIntangibleTimer = 0
    --djui_chat_message_create(tostring(o.oOpacity))
    --bhv_toad_message_loop()
    bhv_bobomb_buddy_loop()
end)

bhvSecretBobomb = hook_behavior(nil, OBJ_LIST_GENACTOR, true, function(o)
    o.oFlags = OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_HOLDABLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW
    o.oAnimations = gObjectAnimations.bobomb_seg8_anims_0802396C
    o.oInteractType = INTERACT_TEXT
    o.hitboxRadius = 160
    o.hitboxHeight = 150
    cur_obj_init_animation(0)
    bhv_bobomb_buddy_init()
end, function(o)
    o.oIntangibleTimer = 0
    bhv_bobomb_buddy_loop()
end)

bhvB3313PlayerNPC = hook_behavior(nil, OBJ_LIST_GENACTOR, true, function(o)
    o.oFlags = OBJ_FLAG_COMPUTE_ANGLE_TO_MARIO | OBJ_FLAG_HOLDABLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW
    o.header.gfx.animInfo.curAnim = get_mario_vanilla_animation(MARIO_ANIM_FIRST_PERSON)
    o.oInteractType = INTERACT_TEXT
    o.hitboxRadius = 100
    o.hitboxHeight = 100
    o.oGraphYOffset = o.oGraphYOffset + 40
    bhv_bobomb_buddy_init()
end, function(o)
    o.oIntangibleTimer = 0
    bhv_bobomb_buddy_loop()
end)