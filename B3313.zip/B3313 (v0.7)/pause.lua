-- name: !  B3313 Pause Menu + Red Coin Tracker !
-- description: New pause menu, including a red coin tracker. Minimal layout and functionality because star tracker and fast travel are separate \n\Original code by Blocky

local zero = {x=0,y=0,z=0}
local m = gMarioStates[0]
local np = gNetworkPlayers[0]
local restartLevelArea = 1

local isPaused = false

local menuActBlacklist = {
    -- Star Acts
    [ACT_FALL_AFTER_STAR_GRAB] = true,
    [ACT_STAR_DANCE_EXIT] = true,
    [ACT_STAR_DANCE_NO_EXIT] = true,
    [ACT_STAR_DANCE_WATER] = true,
    -- Key Acts
    [ACT_UNLOCKING_KEY_DOOR] = true,
    [ACT_UNLOCKING_STAR_DOOR] = true,
    -- Cutscene Acts
    [ACT_INTRO_CUTSCENE] = true,
    [ACT_JUMBO_STAR_CUTSCENE] = true,
    [ACT_END_PEACH_CUTSCENE] = true,
    [ACT_CREDITS_CUTSCENE] = true,
    [ACT_WARP_DOOR_SPAWN] = true,
    [ACT_PULLING_DOOR] = true,
    [ACT_PUSHING_DOOR] = true,
    -- Dialog Acts
    [ACT_READING_NPC_DIALOG] = true,
    [ACT_WAITING_FOR_DIALOG] = true,
    [ACT_EXIT_LAND_SAVE_DIALOG] = true,
    [ACT_READING_AUTOMATIC_DIALOG] = true,
}

--* thanks coolio for the hook & function overwriting

local function is_game_paused_modded()
    return isPaused
end

_G.is_game_paused = is_game_paused_modded

local pause_exit_funcs = {}

local real_hook_event = hook_event


local function close_menu()
    if m.playerIndex ~= 0 then return end
    if isPaused then
        isPaused = false
        play_sound(SOUND_MENU_PAUSE_HIGHPRIO, zero)
        m.controller.buttonPressed = 0
    end
end


local function open_cs()
    _G.charSelect.set_menu_open(true)
    close_menu()
end

local function hud_render()
    if not isPaused then return end
    local zTrigPressed = m.controller.buttonPressed & Z_TRIG ~= 0

    -- Character Select Support
    if _G.charSelectExists then
        local csOptionExists = false
        --[[for _, option in ipairs(pauseMenuLevelOptions) do
            if option.name == "OPEN CHARACTER SELECT" then
                csOptionExists = true
                break
            end
        end]]
        --[[if not csOptionExists then
            table.insert(pauseMenuLevelOptions, {name = "OPEN CHARACTER SELECT", func = open_cs})
        end]]

        if isPaused and _G.charSelect.is_menu_open() then
            close_menu()
        end
        if isPaused and zTrigPressed then
            _G.charSelect.set_menu_open(true)
            close_menu()
        end
    end

    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_font(FONT_TINY)
    local screenHeight = djui_hud_get_screen_height()
    local screenWidth = djui_hud_get_screen_width()
    local optionPosY = screenHeight * 0.55

    djui_hud_set_color(0, 0, 25, 128)
    djui_hud_render_rect(0, 0, screenWidth + 20, screenHeight)
    djui_hud_set_color(255, 255, 255, 255)


    local currCourseNum = gNetworkPlayers[0].currCourseNum
    local currLevelNum = gNetworkPlayers[0].currLevelNum
    local currAreaIndex = gNetworkPlayers[0].currAreaIndex
    local currActNum = gNetworkPlayers[0].currActNum

    -- Displays red coin counter
    local redCoinCourse = (currLevelNum == LEVEL_BOB and currAreaIndex == 7) -- Goomba Hills
        or (currLevelNum == LEVEL_JRB and currAreaIndex == 1) -- Bob Omb River
        or (currLevelNum == LEVEL_CCM and currAreaIndex == 1) -- Jolly Roger Lagoon
        or (currLevelNum == LEVEL_LLL and currAreaIndex == 1) -- Blazing Bully Base
        or (currLevelNum == LEVEL_SSL and currAreaIndex == 1) -- Desert Maze
        or (currLevelNum == LEVEL_SSL and currAreaIndex == 2) -- Shifted Sand Land
        or (currLevelNum == LEVEL_DDD and currAreaIndex == 7) -- Frosty Highlands
        or (currLevelNum == LEVEL_SL and currAreaIndex == 1) -- Floating Hotel
        or (currLevelNum == LEVEL_SL and currAreaIndex == 3) -- Wing Cap by the Rainbow Highway
        or (currLevelNum == LEVEL_TTM and currAreaIndex == 1) -- Tall Tall Mountain
        or (currLevelNum == LEVEL_THI and currAreaIndex == 3) -- Jolly Roger Bay (Beta) (Duplicate)
        or (currLevelNum == LEVEL_THI and currAreaIndex == 4) -- Grassy Highlands
        or (currLevelNum == LEVEL_RR and currAreaIndex == 1) -- Jolly Roger Bay (Beta)
        or (currLevelNum == LEVEL_BITDW and currAreaIndex == 3) -- Creepy Cove
        or (currLevelNum == LEVEL_BITFS and currAreaIndex == 1) -- Aquatic Tunnel
        or (currLevelNum == LEVEL_PSS and currAreaIndex == 5) -- Bob Omb Village
        or (currLevelNum == LEVEL_ENDING and currAreaIndex == 1) -- Flooded Town


    -- Displays small star counter
    local smallStarCourse = (currLevelNum == LEVEL_BBH and currAreaIndex == 1) -- Whomp's Kingdom
        or (currLevelNum == LEVEL_BBH and currAreaIndex == 2) -- Whomp's Prison
        or (currLevelNum == LEVEL_HMC and currAreaIndex == 2) -- Tick Tock Blocks
        or (currLevelNum == LEVEL_HMC and currAreaIndex == 3) -- Midnight Meadow
        or (currLevelNum == LEVEL_HMC and currAreaIndex == 6) -- Cave City
        or (currLevelNum == LEVEL_COTMC and currAreaIndex == 5) -- Tall Floating Fortress


    m.freeze = 1
    local course = np.currCourseNum
    local level = np.currLevelNum
    local area = np.currAreaIndex
    local act = np.currActNum


    local sCoinTextures = {
        [0] = get_texture_info("coin_seg3_texture_03005780"),
        [1] = get_texture_info("coin_seg3_texture_03005F80"),
        [2] = get_texture_info("coin_seg3_texture_03006780"),
        [3] = get_texture_info("coin_seg3_texture_03006F80"),
        [4] = get_texture_info("coin_seg3_texture_03005780"),
     }
     --djui_hud_set_color(0xFF, 0x00, 0x00, 0xFF) -- Red

     local sMiniStarTextures = {
        [0] = get_texture_info("mini_star_seg3_texture_1"),
        [1] = get_texture_info("mini_star_seg3_texture_2"),
        [2] = get_texture_info("mini_star_seg3_texture_3"),
        [3] = get_texture_info("mini_star_seg3_texture_4"),
        [4] = get_texture_info("mini_star_seg3_texture_4"),
     }

     djui_hud_set_font(FONT_HUD)
     djui_hud_print_text("GAME PAUSED", screenWidth * 0.5 - (djui_hud_measure_text("GAME PAUSED") /2), optionPosY - 75, 1 )
     if redCoinCourse or smallStarCourse then
         if redCoinCourse then --djui_hud_render_texture(gTextures.coin, (screenWidth /2) + 80, optionPosY + 80, 1, 1)
             djui_hud_set_color(0xFF, 0x00, 0x00, 0xFF) -- Red
             djui_hud_render_texture(sCoinTextures[math.floor(gMarioStates[0].marioObj.oTimer / 2) % #sCoinTextures], screenWidth - 67, screenHeight - 31.5, 0.6, 0.6) -- spin code by Isaac
             djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF) -- Regular
         elseif smallStarCourse then --djui_hud_render_texture(gTextures.star, (screenWidth /2) + 85, optionPosY + 85, 1, 1) end
             djui_hud_set_color(0xFF, 0xFF, 0x00, 0xFF) -- Yellow
             djui_hud_render_texture(sMiniStarTextures[math.floor(gMarioStates[0].marioObj.oTimer / 1) % #sMiniStarTextures], screenWidth - 65, screenHeight - 29.5, 0.485, 0.485) -- spin code by Isaac
             djui_hud_set_color(0xFF, 0xFF, 0xFF, 0xFF) -- Regular
         end
         djui_hud_print_text(tostring(gMarioStates[0].area.numRedCoins - obj_count_objects_with_behavior_id(id_bhvRedCoin).."/"..gMarioStates[0].area.numRedCoins), screenWidth - 48, screenHeight - 30, 1)
     end
end

local function pressed_pause()
    local c = m.area and m.area.camera or nil
    if get_dialog_id() >= 0 or (_G.charSelectExists and _G.charSelect.is_menu_open()) then
        return false
    end

    return gMarioStates[0].controller.buttonPressed & START_BUTTON ~= 0
end

function before_mario_update()
    local rTrigPressed = m.controller.buttonPressed & R_TRIG ~= 0
    if m.playerIndex ~= 0 then return end

    if pressed_pause() then
        if not isPaused then
            if menuActBlacklist[m.action] then return end
            isPaused = true
            --selectedOption = 1
            m.controller.buttonPressed = 0
            play_sound(SOUND_MENU_PAUSE_HIGHPRIO, zero)
        else
            close_menu()
        end
    elseif rTrigPressed and isPaused then
        close_menu()
        djui_open_pause_menu()
        m.controller.buttonPressed = 0
        play_sound(SOUND_MENU_EXIT_A_SIGN, zero)
    elseif (m.controller.buttonPressed & B_BUTTON ~= 0) and isPaused then
        isPaused = false
        play_sound(SOUND_MENU_PAUSE, m.marioObj.header.gfx.cameraToObject)
    end
end

real_hook_event(HOOK_ON_HUD_RENDER, hud_render)
real_hook_event(HOOK_BEFORE_MARIO_UPDATE, before_mario_update)
real_hook_event(HOOK_ON_WARP, close_menu)
real_hook_event(HOOK_ON_LEVEL_INIT, function () restartLevelArea = gNetworkPlayers[0].currAreaIndex close_menu() end)