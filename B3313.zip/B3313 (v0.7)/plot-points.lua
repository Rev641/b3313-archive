-- Brought to you by Floralys

joinedLives = false
local m = gMarioStates[0]
local introDialogue = true
local lobbyDialogue = true
local course1Dialogue = true
local course2Dialogue = true
local course3Dialogue = true
local course4Dialogue = true
local riverDialogue = true
local battlefieldDialogue = true
local sewerDialogue = true
local cakeDialogue = false
local dialogDelay = 0
local yellowSwitch = false
local castle_grounds_warp_sound = false
local force_ending_warp = false
local flash_fix = false
local countdown_to_credits = 0
local warp_delay = 0
local transition = 0
local mips1_crimson_spawn = false
local random_box_contents = 0

-- troll 1up noise by wingstosky256
function play_waahwaahwaah_init(o)
    o.hitboxRadius = 25
    o.hitboxHeight = 45
end
function play_waahwaahwaah_loop(o)
    local m = gMarioStates[0]
    if obj_check_hitbox_overlap(o, gMarioStates[0].marioObj) == true and gMarioStates[0].playerIndex == 0 then
        audio_sample_stop(SOUND_BETA_FAKE_1UP)
        audio_sample_play(SOUND_BETA_FAKE_1UP, gMarioStates[0].pos, 2)
        obj_mark_for_deletion(o)
    end
end

function troll_waahwaah_in_castle(posX, posY, posZ)
    return spawn_non_sync_object(id_bhvWaahWaah, E_MODEL_NONE, posX, posY, posZ, nil)
end

id_bhvWaahWaah = hook_behavior(nil, OBJ_LIST_GENACTOR, false, play_waahwaahwaah_init, play_waahwaahwaah_loop, "waahwaah")


-- Hide Peach's dialogue text during the credits
function hide_peach_dialog()
    djui_hud_set_resolution(RESOLUTION_N64)
    if gMarioStates[0].action == ACT_END_PEACH_CUTSCENE then
        djui_hud_set_color(0, 0, 0, 255)
        djui_hud_render_rect(0, screenHeight - 30, screenWidth + 1, screenHeight)
        djui_hud_render_rect(0, 0, screenWidth + 1, 30)
    end

    -- Try to fix a one frame flash of castle grounds
    --if (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1) and force_ending_warp then
    if flash_fix then
        --play_transition(WARP_TRANSITION_FADE_FROM_STAR, 15, 0, 0, 0)
        djui_hud_set_color(0, 0, 0, 255)
        djui_hud_render_rect(0, 0, screenWidth + 1, screenHeight + 1)
    end
end
hook_event(HOOK_ON_HUD_RENDER, hide_peach_dialog)

---@param m MarioState
hook_event(HOOK_MARIO_UPDATE, function(m)
    if m.playerIndex ~= 0 then return end

    -- Start with 2 lives
    if not joinedLives then
        m.numLives = 2
        currNumLives = m.numLives
        currLivesPlaceholder = m.numLives
        set_mario_action(m, ACT_FIRST_PERSON, 0)
        joinedLives = true
    end

    if m.numLives > currNumLives then
        audio_sample_play(SOUND_BETA_1UP, m.pos, 1)
        currNumLives = m.numLives
    end

    -- Respawn with 2 lives after game over
    if m.numLives < 0 then
        warp_delay = warp_delay + 1
        if (warp_delay >= 19 and (m.floor ~= nil and m.floor.type == SURFACE_DEATH_PLANE and m.pos.y < m.floorHeight + 2048)) or (warp_delay >= 47) then
            play_transition(WARP_TRANSITION_FADE_FROM_STAR, 15, 0, 0, 0)
            warp_to_warpnode(LEVEL_THI, 1, 0, 10)
            m.numLives = 2
            m.health = 0x880
            set_mario_action(m, ACT_SPAWN_SPIN_AIRBORNE, 0)
            currNumLives = m.numLives
            castle_grounds_warp_sound = true
            warp_delay = 0
        end
    end
    if (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1) and castle_grounds_warp_sound then
        play_sound(SOUND_MENU_MARIO_CASTLE_WARP, m.pos)
        castle_grounds_warp_sound = false
    end

    -- Force the intended ending without the weird post-game sheninigans Coop does. Also puts you at the same spot if you skip the credits or not
    if (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1) and force_ending_warp then
        warp_to_warpnode(LEVEL_BITFS, 4, 99, 10)
        if m.numLives < currNumLives then
            m.numLives = m.numLives + 1
        end
        force_ending_warp = false
        flash_fix = false
        countdown_to_credits = 0
    end 

    -- Intro text
    if (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1) and introDialogue == true then
        dialogDelay = dialogDelay + 1
        if dialogDelay >= 2 then
            --cutscene_object_with_dialog(CUTSCENE_DIALOG, gMarioStates[0].marioObj, DIALOG_066) -- For 0.9 intro
            create_dialog_box(66)  -- For 0.7 intro
            introDialogue = false
            dialogDelay = 0
        end
    end
    -- First lobby entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS and (gNetworkPlayers[0].currAreaIndex == 3 or gNetworkPlayers[0].currAreaIndex == 4)) and lobbyDialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE and m.action ~= ACT_WARP_DOOR_SPAWN then  
            create_dialog_box(0)
            lobbyDialogue = false
        end
    end
    -- Mountain (B-Roll) entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_COTMC and gNetworkPlayers[0].currAreaIndex == 1) and course1Dialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(32)
            course1Dialogue = false
        end
    end
    -- Fire Bubble (B-Roll) entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_LLL and (gNetworkPlayers[0].currAreaIndex == 1 or gNetworkPlayers[0].currAreaIndex == 5)) and course2Dialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(97)
            course2Dialogue = false
        end
    end
    -- Snow Slide (B-Roll) entry
    if ((gNetworkPlayers[0].currLevelNum == LEVEL_DDD and gNetworkPlayers[0].currAreaIndex == 5) or (gNetworkPlayers[0].currLevelNum == LEVEL_WDW and gNetworkPlayers[0].currAreaIndex == 1)) and course3Dialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(30)
            course3Dialogue = false
        end
    end
    -- Water Land (Shoshinkai) entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_WMOTR and gNetworkPlayers[0].currAreaIndex == 1) and course4Dialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(35)
            course4Dialogue = false
        end
    end
    -- River Mountain entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_JRB and gNetworkPlayers[0].currAreaIndex == 1) and riverDialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(36)
            riverDialogue = false
        end
    end
    -- Bob-Omb Battlefield entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_BITS and gNetworkPlayers[0].currAreaIndex == 4) and battlefieldDialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(52)
            battlefieldDialogue = false
        end
    end
    -- Scary Sewer Maze entry
    if (gNetworkPlayers[0].currLevelNum == LEVEL_SSL and gNetworkPlayers[0].currAreaIndex == 3) and sewerDialogue == true then
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            create_dialog_box(78)
            sewerDialogue = false
        end
    end
    -- Cake text
    if (gNetworkPlayers[0].currLevelNum == LEVEL_DDD and gNetworkPlayers[0].currAreaIndex == 4 and gNetworkPlayers[0].currActNum == 99) and cakeDialogue == true then 
        if m.action ~= ACT_SPAWN_SPIN_AIRBORNE and m.action ~= ACT_SPAWN_NO_SPIN_AIRBORNE then
            local PeachNPC = obj_get_first_with_behavior_id(bhvB3313Peach)
            if PeachNPC ~= nil then
                cutscene_object_with_dialog(CUTSCENE_DIALOG, PeachNPC, DIALOG_148)
            end
            cakeDialogue = false
        end
    end

    -- Do not kill player in Peach's Cell
    local peach_cell = (gNetworkPlayers[m.playerIndex].currLevelNum == LEVEL_THI and ((gNetworkPlayers[m.playerIndex].currAreaIndex == 6) or (gNetworkPlayers[m.playerIndex].currAreaIndex == 7))) 
    if peach_cell and (m.numLives < currNumLives or currLivesPlaceholder < currNumLives) then
        m.numLives = currNumLives
        currLivesPlaceholder = currNumLives - 1
        warp_delay = warp_delay + 1
        if warp_delay >= 47 then
            --play_transition(WARP_TRANSITION_FADE_FROM_STAR, 15, 0, 0, 0)
            warp_to_warpnode(LEVEL_TTC, 7, gNetworkPlayers[0].currActNum, 8)
            m.numLives = currNumLives
            m.health = 0x880
            set_mario_action(m, ACT_SPAWN_SPIN_AIRBORNE, 0)
            warp_delay = 0
        end
    end

    -- Do not kill player falling from Balcony to Uncanny Courtyard
    local balcony = (gNetworkPlayers[m.playerIndex].currLevelNum == LEVEL_RR and gNetworkPlayers[m.playerIndex].currAreaIndex == 5)
    if balcony and (m.numLives < currNumLives or currLivesPlaceholder < currNumLives) then
        m.numLives = currNumLives
        currLivesPlaceholder = currNumLives - 1
        warp_delay = warp_delay + 1
        if (warp_delay >= 19 and (m.floor ~= nil and m.floor.type == SURFACE_DEATH_PLANE and m.pos.y < m.floorHeight + 2048)) then
            play_transition(WARP_TRANSITION_FADE_FROM_STAR, 15, 0, 0, 0)
            warp_to_warpnode(LEVEL_CASTLE_COURTYARD, 7, gNetworkPlayers[0].currActNum, 10)
            m.numLives = currNumLives
            m.health = 0x880
            set_mario_action(m, ACT_SPAWN_SPIN_AIRBORNE, 0)
            warp_delay = 0
        end
    end

    -- Jumbo Star Cutscene interrupt
    if m.action == ACT_JUMBO_STAR_CUTSCENE and m.actionTimer >= 483 then
        force_ending_warp = true
        --[[if transition == 0 then
            play_transition(WARP_TRANSITION_FADE_INTO_STAR, 15, 0, 0, 0)
            transition = 1
        end
        warp_delay = warp_delay + 1
        if warp_delay >= 19 then
            --warp_to_warpnode(LEVEL_TTC, 6, gNetworkPlayers[0].currActNum, 45)
            --warp_to_warpnode(LEVEL_TTC, 3, gNetworkPlayers[0].currActNum, 10)
            warp_to_warpnode(LEVEL_DDD, 4, 99, 10)
            warp_delay = 0
            transition = 0
        end]]
    end

    if m.action == ACT_END_PEACH_CUTSCENE then
        countdown_to_credits = countdown_to_credits + 1
        if countdown_to_credits >= 3215 then
            flash_fix = true
        end
        --djui_chat_message_create(tostring(countdown_to_credits))
    end

    -- Pressing the Yellow Switch
    local isInDialog = get_dialog_box_state()
    local yellowSwitchPalace = gNetworkPlayers[0].currLevelNum == LEVEL_CCM and ((gNetworkPlayers[0].currAreaIndex == 5) or (gNetworkPlayers[0].currAreaIndex == 6))
    local yellowSwitchLake = gNetworkPlayers[0].currLevelNum == LEVEL_CCM and (gNetworkPlayers[0].currAreaIndex == 1)
    if yellowSwitchPalace and get_dialog_id() == 13 then
        dialogID = 3
    end
    if (yellowSwitchLake and get_dialog_id() == 13) or (yellowSwitchPalace and (isInDialog ~= 0 and get_dialog_id() ~= 73 and get_dialog_id() ~= 74)) then
        if not yellowSwitch then
            save_file_set_flags(SAVE_FLAG_FILE_EXISTS)
            -- unlocked flags
            save_file_set_flags(SAVE_FLAG_MOAT_DRAINED)
            save_file_set_flags(SAVE_FLAG_UNLOCKED_50_STAR_DOOR)
            save_file_set_flags(SAVE_FLAG_UNLOCKED_CCM_DOOR)
            save_file_set_flags(SAVE_FLAG_UNLOCKED_PSS_DOOR)
            save_file_set_flags(SAVE_FLAG_HAVE_KEY_2)
            -- star flags
            save_file_set_flags(SAVE_FLAG_COLLECTED_MIPS_STAR_2)
            save_file_set_flags(SAVE_FLAG_COLLECTED_TOAD_STAR_1)
            save_file_set_flags(SAVE_FLAG_COLLECTED_TOAD_STAR_2)
            save_file_set_flags(SAVE_FLAG_COLLECTED_TOAD_STAR_3)
            -- no cap flags (actually don't need lmao but they're here for reference) 
            --[[save_file_set_flags(SAVE_FLAG_CAP_ON_GROUND)
            save_file_set_flags(SAVE_FLAG_CAP_ON_KLEPTO)
            save_file_set_flags(SAVE_FLAG_CAP_ON_MR_BLIZZARD)
            save_file_set_flags(SAVE_FLAG_CAP_ON_UKIKI)]]
            --djui_popup_create("YELLOW SWITCH PRESSED >:3", 1)
            yellowSwitch = true
        end
        set_mario_animation(m, CHAR_ANIM_MISSING_CAP)
    end
    if yellowSwitch then
        if (m.flags == m.flags | MARIO_WING_CAP and not fakewings) or (m.flags == m.flags | MARIO_VANISH_CAP) or (m.flags == m.flags | MARIO_METAL_CAP) then return 
        else
            m.flags = m.flags & ~MARIO_CAP_ON_HEAD
        end
    end

    -- Set box content
    random_box_contents = math.random(0,10)
    set_exclamation_box_contents({
        {id = 0, unused = 0, firstByte = 0, model = E_MODEL_MARIOS_WING_CAP, behavior = id_bhvWingCap },
        {id = 1, unused = 0, firstByte = 0, model = E_MODEL_MARIOS_METAL_CAP, behavior = id_bhvMetalCap },
        {id = 2, unused = 0, firstByte = 0, model = E_MODEL_MARIOS_CAP, behavior = id_bhvVanishCap },
        {id = 3, unused = 0, firstByte = 0, model = E_MODEL_KOOPA_SHELL, behavior = id_bhvKoopaShell },
        {id = 4, unused = 0, firstByte = 0, model = E_MODEL_YELLOW_COIN, behavior = id_bhvSingleCoinGetsSpawned },
        {id = 5, unused = 0, firstByte = 0, model = E_MODEL_NONE, behavior = id_bhvThreeCoinsSpawn },
        {id = 6, unused = 0, firstByte = 0, model = E_MODEL_NONE, behavior = id_bhvTenCoinsSpawn },
        {id = 7, unused = 0, firstByte = 0, model = E_MODEL_1UP, behavior = id_bhv1upWalking },
        {id = 8, unused = 0, firstByte = 0, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        {id = 9, unused = 0, firstByte = 0, model = E_MODEL_1UP, behavior = id_bhv1upRunningAway },
        {id = 10, unused = 0, firstByte = 1, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        {id = 11, unused = 0, firstByte = 2, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        {id = 12, unused = 0, firstByte = 3, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        {id = 13, unused = 0, firstByte = 4, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        {id = 14, unused = 0, firstByte = 5, model = E_MODEL_STAR, behavior = id_bhvSpawnedStar },
        --{id = 15, unused = 0, firstByte = 0, model = E_MODEL_NONE, behavior = nil}, -- End of vanilla behaviors, also is literally blank
        {id = 16, unused = 0, firstByte = 0, model = E_MODEL_BLACK_BOBOMB, behavior = bhvSecretBobomb },
        {id = 17, unused = 0, firstByte = 1, model = E_MODEL_BLACK_BOBOMB, behavior = id_bhvBobomb },
        {id = 18, unused = 0, firstByte = 0, model = E_MODEL_FACELESS_B, behavior = id_bhvBreakableBoxSmall },
        {id = 19, unused = 0, firstByte = 0, model = E_MODEL_FACELESS_A, behavior = id_bhvHidden1upInPole },
        {id = 20, unused = 0, firstByte = 0, model = E_MODEL_1UP, behavior = id_bhvHidden1upInPole },
        {id = 21, unused = 0, firstByte = 0, model = E_MODEL_BEEIE_CHUNGUS, behavior = bhvB3313PlayerNPC },
        {id = 22, unused = 0, firstByte = 0, model = E_MODEL_GOOMBA, behavior = id_bhvGoomba },
        {id = 23, unused = 0, firstByte = 0, model = E_MODEL_CHUCKYA, behavior = id_bhvChuckya },
        {id = 24, unused = 0, firstByte = 0, model = E_MODEL_FLYGUY, behavior = id_bhvFlyGuy },
        {id = 25, unused = 0, firstByte = 0, model = E_MODEL_KLEPTO, behavior = id_bhvKlepto }
    })
end)

-- Mutes either music or sound effects upon a certain dialog cue from Toad
hook_event(HOOK_ON_DIALOG, function (dialogID)
    if dialogID == 19 and areas[gNetworkPlayers[m.playerIndex].currLevelNum] ~= nil then
        --fadeout_level_music(25)
        seq_player_lower_volume(SEQ_PLAYER_SFX, 25, 0) -- Fadeout sound effects only (0.7 behavior, includes default Mario voice but not custom voices)
        playB3313SFX = false
    end
end)

-- 1up replacement code by IncredibleHolc
local function before_phys_step(m,stepType) --Called once per player per frame before physics code is run, return an integer to cancel it with your own step result
    local m = gMarioStates[0]
    if m.playerIndex ~= 0 then
        return
    end
	
    local Standard1up = obj_get_nearest_object_with_behavior_id(m.marioObj,id_bhv1Up) 
    if Standard1up ~= nil and (nearest_interacting_mario_state_to_object(Standard1up)).playerIndex == 0 and is_within_100_units_of_mario(Standard1up.oPosX, Standard1up.oPosY, Standard1up.oPosZ) == 1 then --if local mario is touching 1up then
        obj_mark_for_deletion(Standard1up)
        --m.numLives = m.numLives - 1
        audio_sample_play(SOUND_BETA_FAKE_1UP, m.pos, 3)
    end
end
hook_event(HOOK_BEFORE_PHYS_STEP, before_phys_step)


--On interact
function on_interact(m, o, intType, interacted)
    local s = gStateExtras[m.playerIndex]
    local np = gNetworkPlayers[0]
    print(get_behavior_name_from_id(get_id_from_behavior(o.behavior)))

    local yellowSwitchPalace = gNetworkPlayers[0].currLevelNum == LEVEL_CCM and ((gNetworkPlayers[0].currAreaIndex == 5) or (gNetworkPlayers[0].currAreaIndex == 6))
    if (obj_has_behavior_id(o,bhvSecretBobomb)) ~= 0 then
        if yellowSwitchPalace then
            --if not yellowSwitch then
            --    o.oBehParams2ndByte = 73
            if yellowSwitch then
                o.oBehParams2ndByte = 74
            end
        else
            o.oBehParams2ndByte = 68
        end
    end
    if (obj_has_behavior_id(o,bhvB3313Peach)) ~= 0 and ((m.controller.buttonPressed & B_BUTTON) + (m.action & ACT_FLAG_ATTACKING) ~= 0) then
        play_sound(SOUND_ACTION_TELEPORT, m.marioObj.header.gfx.cameraToObject)
        obj_mark_for_deletion(o)
        --m.health = 0
        if m.action & ACT_FLAG_AIR == 0 then
            set_mario_action(m, ACT_PUNCHING, 0)
        end
    end
    if (obj_has_behavior_id(o,bhvB3313PlayerNPC)) ~= 0 then
        if not (gNetworkPlayers[0].currLevelNum == LEVEL_VCUTM and gNetworkPlayers[0].currAreaIndex == 4) then
            o.oBehParams2ndByte = 169
        end
    end

    if (obj_has_behavior_id(o,id_bhvYoshi)) ~= 0 then
        if gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1 and m.numStars >= 146 and m.pos.y <= -171 then
            o.oBehParams2ndByte = 51
        elseif gNetworkPlayers[0].currLevelNum ~= LEVEL_THI or (gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex ~= 1) then
            o.oBehParams2ndByte = 134
        end
    end
end
hook_event(HOOK_ON_INTERACT, on_interact)


function green_demon(unloadedObj)
    nearest = nearest_mario_state_to_object(unloadedObj)
    if (get_id_from_behavior(unloadedObj.behavior) == id_bhvHidden1upInPole and nearest.playerIndex == 0) then
        if (obj_has_model_extended(unloadedObj, E_MODEL_NONE) ~= 0) or (obj_has_model_extended(unloadedObj, E_MODEL_FACELESS_A) ~= 0) then
		    m.health = 0
            m.numLives = m.numLives - 1
        else
            m.numLives = m.numLives - 1
            audio_sample_play(SOUND_BETA_FAKE_1UP, m.pos, 3)
        end
    end
end

hook_event(HOOK_ON_OBJECT_UNLOAD, green_demon)




--local m = gMarioStates[0]
--local warp_delay = 0

function fakewarp_init(o)
    o.hitboxRadius = 1500
    o.hitboxHeight = 2000
end

is_warping = false
---@param o Object
function fakewarp_loop(o)
    if (dist_between_objects(o, gMarioStates[0].marioObj)) <= 50 then
        is_warping = true
    end
    if is_warping then
        if transition == 0 then
            play_transition(WARP_TRANSITION_FADE_INTO_STAR, 15, 0, 0, 0)
            play_sound(SOUND_MENU_ENTER_HOLE, m.pos)
            transition = 1
        end
        warp_delay = warp_delay + 1
        if warp_delay >= 20 then
            warp_to_level(dest_level, dest_area, gNetworkPlayers[0].currActNum)
            set_mario_action(m, ACT_SPAWN_SPIN_AIRBORNE, 0)
            warp_delay = 0
            is_warping = false
            transition = 0
        end
    end
end

bhvFakeWarp = hook_behavior(nil, OBJ_LIST_LEVEL, true, fakewarp_init, fakewarp_loop, "Fake Warp")

bhvCustomBoxSpawn = hook_behavior(nil, OBJ_LIST_GENACTOR, true, nil, nil)

E_MODEL_FACELESS_A = smlua_model_util_get_id("custom_geo_0700b630")
E_MODEL_FACELESS_B = smlua_model_util_get_id("custom_geo_07016c90")

-- Placing extra 1ups (some had to be removed from the level bins to work just right)
hook_event(HOOK_ON_SYNC_VALID, function()
    -- Mario's Maze fix
    if gNetworkPlayers[0].currLevelNum == LEVEL_BITDW and gNetworkPlayers[0].currAreaIndex == 6 then
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_FACELESS_A, 5610, 0, 1342, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)	
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_FACELESS_A, 603, 0, -4945, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_FACELESS_A, 53817, 0, -9882, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_FACELESS_A, 1050, 0, 1085, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)
        spawn_sync_object(id_bhvUnagi, E_MODEL_FACELESS_B, 3705,0,-4656, nil)
        spawn_sync_object(id_bhvUnagi, E_MODEL_FACELESS_B, 4278,0,955, nil)
    end
    -- Empty HMC fix
    if gNetworkPlayers[0].currLevelNum == LEVEL_HMC and gNetworkPlayers[0].currAreaIndex == 1 then
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_NONE, -759, 2056, 8003, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)	
    end
    -- Sinister Clockwork fix
    if gNetworkPlayers[0].currLevelNum == LEVEL_COTMC and gNetworkPlayers[0].currAreaIndex == 3 then
        spawn_sync_object(id_bhvHidden1upInPole, E_MODEL_NONE, gMarioStates[0].pos.x, gMarioStates[0].pos.y + 100, gMarioStates[0].pos.z + 3000, function(o) o.oBehParams2ndByte = 2 o.oAction = 3 end)	
    end

    -- Silly boxes
    local box_spawn = obj_get_first_with_behavior_id(bhvCustomBoxSpawn)
    if m.numStars >= 120 then
        if gNetworkPlayers[0].currLevelNum == LEVEL_BOB then
            if gNetworkPlayers[0].currAreaIndex == 4 then
                if box_spawn == nil then
                    random_box_contents = math.random(0,10)
                    spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -4473, 3000, -2554, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                    spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
                end
            elseif gNetworkPlayers[0].currAreaIndex == 7 then
                if box_spawn == nil then
                    random_box_contents = math.random(0,10)
                    spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 2038, 294, 13351, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                    spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
                end
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_WF and gNetworkPlayers[0].currAreaIndex == 3 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -11713, 300, 7469, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 1072, 459, -91, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_JRB and gNetworkPlayers[0].currAreaIndex == 1 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 6721, 1217, -11704, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_SL and gNetworkPlayers[0].currAreaIndex == 1 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 5240, 300, -8866, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[0].currAreaIndex == 5 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -2002, -1520, 666, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -8778, -712, -3980, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -7202, 300, -12954, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_COURTYARD then
            if gNetworkPlayers[0].currAreaIndex == 1 then
                if box_spawn == nil then
                    random_box_contents = math.random(0,10)
                    spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -6754, -947, -17396, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                    spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
                end
            elseif gNetworkPlayers[0].currAreaIndex == 7 then
                if box_spawn == nil then
                    random_box_contents = math.random(0,10)
                    spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -4638, -947, -11186, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                    spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
                end
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_VCUTM and gNetworkPlayers[0].currAreaIndex == 2 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, -12286, 1926, -24216, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                --random_box_contents = math.random(0,10)
                --spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 7445, 1058, -10912, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
        if gNetworkPlayers[0].currLevelNum == LEVEL_WMOTR and gNetworkPlayers[0].currAreaIndex == 5 then
            if box_spawn == nil then
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 10161, -1016, -5555, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 10161, -1016, -5855, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                random_box_contents = math.random(0,10)
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 10161, -1016, -5255, function(o) o.oBehParams2ndByte = random_box_contents + 16 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
    end
    
    -- Spawn back up star boxes for Crimson Hall and Wing Cap by the Rainbow Highway (in case ya missed MIPs 1)
    if (gNetworkPlayers[0].currLevelNum == LEVEL_BOB and gNetworkPlayers[0].currAreaIndex == 1) then
        if save_file_get_flags() & SAVE_FLAG_COLLECTED_MIPS_STAR_1 ~= 0 then
            if box_spawn == nil then
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 808, 300, 2319, function(o) o.oBehParams2ndByte = 12 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
    end
    if (gNetworkPlayers[0].currLevelNum == LEVEL_SL and gNetworkPlayers[0].currAreaIndex == 3) then
        if save_file_get_flags() & SAVE_FLAG_COLLECTED_MIPS_STAR_1 ~= 0 then
            if box_spawn == nil then
                spawn_sync_object(id_bhvExclamationBox, E_MODEL_EXCLAMATION_BOX, 3941, 4124, 3504, function(o) o.oBehParams2ndByte = 12 end)
                spawn_sync_object(bhvCustomBoxSpawn, E_MODEL_NONE, 0, 0, 0, nil)
            end
        end
    end
end)

E_MODEL_NPC_LUIGI = smlua_model_util_get_id("luigi_fluffa_fixes_geo")

hook_event(HOOK_ON_WARP, function()
    currNumLives = gMarioStates[0].numLives
    currLivesPlaceholder = gMarioStates[0].numLives
    cakeDialogue = true
    if not playB3313SFX then
        playB3313SFX = true -- restore beta voice and SFX if they were turned off
        seq_player_unlower_volume(SEQ_PLAYER_SFX, 25)
    end

    --Lobby 1up fix by wingstosky256
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS and (gNetworkPlayers[0].currAreaIndex == 3 or gNetworkPlayers[0].currAreaIndex == 4) then
        local Lobby1up = obj_get_first_with_behavior_id(id_bhv1Up)

        while Lobby1up ~= nil do
            if obj_has_behavior_id(Lobby1up, id_bhv1Up) ~= 0 then
                obj_mark_for_deletion(Lobby1up)
            end
            Lobby1up = obj_get_next_with_same_behavior_id(Lobby1up)
        end

        troll_waahwaah_in_castle(-84, 92, 320) --main door 

        --hallway coords (Lobby A only, Lobby B doesn't have that hall)
        troll_waahwaah_in_castle(-32, 287, -1768)
        troll_waahwaah_in_castle(-16, 343, -2788)

    elseif gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[0].currAreaIndex == 2 then
        local Lobby1up = obj_get_first_with_behavior_id(id_bhv1Up)

        while Lobby1up ~= nil do
            if obj_has_behavior_id(Lobby1up, id_bhv1Up) ~= 0 then
                obj_mark_for_deletion(Lobby1up)
            end
            Lobby1up = obj_get_next_with_same_behavior_id(Lobby1up)
        end

        troll_waahwaah_in_castle(1452, 136, 320) --main door (3313)
        troll_waahwaah_in_castle(-152, -16, 1024) --connecting door
        troll_waahwaah_in_castle(-1906, 136, 320) --main door (123)

        --hallway coords (Lobby C)
        troll_waahwaah_in_castle(1460, 138, -140)
        troll_waahwaah_in_castle(1489, 343, -1094)
        troll_waahwaah_in_castle(1510, 343, -1983)
        troll_waahwaah_in_castle(1499, 343, -2790)
    end
end)

hook_event(HOOK_ON_LEVEL_INIT, function()
    --spawn temp warps
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[0].currAreaIndex == 1 then -- Ending Grounds (to 2nd Floor Beta)
        spawn_non_sync_object(bhvFakeWarp, E_MODEL_NONE, 12, 550, -6005, function(o) dest_level = LEVEL_VCUTM dest_area = 4 end)
    end
    if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE and gNetworkPlayers[0].currAreaIndex == 1 then -- Inside vanilla lobby (to long Crimson Courtyard)
        spawn_non_sync_object(bhvFakeWarp, E_MODEL_NONE, 1990, 819, 1236, function(o) dest_level = LEVEL_BITDW dest_area = 2 end)
    end

    -- Peach NPC
    if gNetworkPlayers[0].currLevelNum == LEVEL_DDD and gNetworkPlayers[0].currAreaIndex == 4 and gNetworkPlayers[0].currActNum == 99 then 
        spawn_non_sync_object(bhvB3313Peach, E_MODEL_PEACH, 2350, 0, -1600, function(o) o.oFaceAngleYaw = -6000 end)
    end

    -- chungus
    if gNetworkPlayers[0].currLevelNum == LEVEL_VCUTM and gNetworkPlayers[0].currAreaIndex == 4 then 
        spawn_non_sync_object(bhvB3313PlayerNPC, E_MODEL_BEEIE_CHUNGUS, -810, 0, -2650, function(o) o.oBehParams2ndByte = 33 end)
    end

    --"100%" bonus interactions (bobombs)
    if gNetworkPlayers[0].currLevelNum == LEVEL_SA and gNetworkPlayers[0].currAreaIndex == 1 and m.numStars >= 120 then 
        spawn_non_sync_object(bhvSecretBobomb, E_MODEL_BLACK_BOBOMB, 4030, 0, 30519, nil)
    end
    if gNetworkPlayers[0].currLevelNum == LEVEL_PSS and gNetworkPlayers[0].currAreaIndex == 1 and m.numStars >= 120 then 
        spawn_non_sync_object(bhvSecretBobomb, E_MODEL_BLACK_BOBOMB, -863, -1563, -11719, nil)
    end
    if gNetworkPlayers[0].currLevelNum == LEVEL_CCM and ((gNetworkPlayers[0].currAreaIndex == 6) or (gNetworkPlayers[0].currAreaIndex == 5 and m.numStars >= 33)) then 
        spawn_non_sync_object(bhvSecretBobomb, E_MODEL_BOBOMB_BUDDY, 1151, 6005, -7171, function(o) o.oBehParams2ndByte = 73 end)
    end

    -- Secret Toad
    if gNetworkPlayers[0].currLevelNum == LEVEL_THI and gNetworkPlayers[0].currAreaIndex == 1 and m.numStars >= 146 then 
        if not yellowSwitch then
            --spawn_non_sync_object(bhvB3313PlayerNPC, E_MODEL_NPC_LUIGI, 2355, -1084, -8038, function(o) o.oFaceAngleYaw = 36000 o.oBehParams2ndByte = 50 end)
            spawn_non_sync_object(id_bhvToadMessage, E_MODEL_TOAD, 2355, -1084, -8038, function(o) o.oFaceAngleYaw = 36000 o.oBehParams = 50 << 24 end)
        else
            spawn_non_sync_object(id_bhvBobombBuddy, E_MODEL_BOBOMB_BUDDY, 2355, -1084, -8038, function(o) o.oFaceAngleYaw = 36000 o.oBehParams2ndByte = 72 end)
        end
    end
end)