-- name: Old Mario
-- incompatible:
-- description: b3313 version

gStateExtras = {}
for i = 0,(MAX_PLAYERS - 1) do
    gStateExtras[i] = {}
    m = gMarioStates[i]
    e = gStateExtras[i]

	e.rotAngle = 0
	e.healTimer = 0
    e.animFrame = 0

	gPlayerSyncTable[i].vanillaMario = false
	gPlayerSyncTable[i].B3313_Moveset = true
    gPlayerSyncTable[i].shadeR = shadeState
    gPlayerSyncTable[i].shadeG = shadeState
    gPlayerSyncTable[i].shadeB = shadeState
end


--------------------
-- MODEL HANDLING --
--------------------

E_MODEL_BEEIE_MARIO = smlua_model_util_get_id("beeie_mario_geo")
E_MODEL_BEEIE_LUIGI = smlua_model_util_get_id("beeie_luigi_geo")
E_MODEL_BEEIE_CHUNGUS = smlua_model_util_get_id("beeie_chungus_geo")

local chungus = false

-- Shading
local defaultShade = 127
local shoshinkaiShade = 63
local shadeState = shoshinkaiShade


function model_handling(m)
	if chungus then
		gPlayerSyncTable[m.playerIndex].modelId = E_MODEL_BEEIE_CHUNGUS
	else
		if m.character.type == CT_MARIO then
			gPlayerSyncTable[m.playerIndex].modelId = E_MODEL_BEEIE_MARIO
		elseif m.character.type == CT_LUIGI then
			gPlayerSyncTable[m.playerIndex].modelId = E_MODEL_BEEIE_LUIGI
		else
			gPlayerSyncTable[m.playerIndex].modelId = nil
		end
		--gPlayerSyncTable[m.playerIndex].modelId = nil
	end
end

function mario_update_local(m)
    --if _G.charSelectExists then return end
	if not gPlayerSyncTable[0].vanillaMario then
		if _G.charSelectExists then
			if _G.charSelect.character_get_current_number() == 1 then 	
				model_handling(m)
			else
				gPlayerSyncTable[m.playerIndex].modelId = nil
			end
		else
			model_handling(m)
		end
	else
		gPlayerSyncTable[m.playerIndex].modelId = nil
    end
end

function set_model(o, model)
	if obj_has_behavior_id(o, id_bhvMario) ~= 0 then
        local i = network_local_index_from_global(o.globalPlayerIndex)
        if gPlayerSyncTable[i].modelId ~= nil and obj_has_model_extended(o, gPlayerSyncTable[i].modelId) == 0 then
            obj_set_model_extended(o, gPlayerSyncTable[i].modelId)
        end
        return
    end
end

hook_event(HOOK_OBJECT_SET_MODEL, set_model)


function betaShadingAndTilt(m)
    if m.playerIndex == 0 then
        mario_update_local(m)
	end

	if not gPlayerSyncTable[m.playerIndex].vanillaMario then
		m.marioBodyState.shadeR = shoshinkaiShade
		m.marioBodyState.shadeG = shoshinkaiShade
		m.marioBodyState.shadeB = shoshinkaiShade
		if m.action == ACT_WALKING or m.action == ACT_BUTT_SLIDE or m.action == ACT_RIDING_SHELL_GROUND or m.action == ACT_RIDING_SHELL_JUMP or m.action == ACT_RIDING_SHELL_FALL then
			m.marioBodyState.torsoAngle.x = 0
			m.marioBodyState.torsoAngle.z = 0
		end
		-- beta crouch handler
		if m.marioObj.header.gfx.animInfo.animID == MARIO_ANIM_STOP_CROUCHING then
			smlua_anim_util_set_animation(m.marioObj, "stop_crouching")
		end
		if m.marioObj.header.gfx.animInfo.animID == MARIO_ANIM_START_CROUCHING then
			smlua_anim_util_set_animation(m.marioObj, "start_crouching")
		end
		if m.marioObj.header.gfx.animInfo.animID == MARIO_ANIM_CROUCHING then
			smlua_anim_util_set_animation(m.marioObj, "crouching")
		end
	elseif gPlayerSyncTable[m.playerIndex].vanillaMario then
		m.marioBodyState.shadeR = defaultShade
		m.marioBodyState.shadeG = defaultShade
		m.marioBodyState.shadeB = defaultShade
	end

	if gPlayerSyncTable[m.playerIndex].B3313_Moveset then
		if m.action == ACT_WALKING or m.action == ACT_BUTT_SLIDE or m.action == ACT_RIDING_SHELL_GROUND or m.action == ACT_RIDING_SHELL_JUMP or m.action == ACT_RIDING_SHELL_FALL then
			m.marioBodyState.torsoAngle.x = 0
			m.marioBodyState.torsoAngle.z = 0
		end
	end
end

------------------
-- MOVESET CODE --
------------------

--B3313_Moveset = true
enableBeeie09 = false
bluigiSlideFix = false

for mod in pairs(gActiveMods) do
    local m = gMarioStates[0]
    if gActiveMods[mod].name == "Character Movesets"
    or gActiveMods[mod].name == "CMS Cancelled WL Moveset"
    or gActiveMods[mod].name == "Character Movesets w/ Animations" 
	or gActiveMods[mod].name == "CMS Cancelled WL Moveset w/ Animations" then
		bluigiSlideFix = true
    end
end

ACT_GROUND_POUND_B3313 = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING)
function act_ground_pound_b3313(m)
    local e = gStateExtras[m.playerIndex]
    --if not E3313 then
	    if m.actionTimer == 0 then
		    m.vel.y = -45
		    e.animFrame = 2
		    play_sound(SOUND_ACTION_SPIN, m.marioObj.header.gfx.cameraToObject)
		    play_character_sound(m, CHAR_SOUND_GROUND_POUND_WAH)
	    end
	    mario_set_forward_vel(m, 0)
	    m.vel.y = m.vel.y + 1.75

	    local stepResult = perform_air_step(m, 0)
	    if stepResult == AIR_STEP_LANDED then
		    if should_get_stuck_in_ground(m) ~= 0 then
			    queue_rumble_data_mario(m, 5, 80)
			    play_sound(SOUND_MARIO_OOOF2, m.marioObj.header.gfx.cameraToObject)
			    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
			    set_mario_action(m, ACT_BUTT_STUCK_IN_GROUND, 0)
		    else
			    play_mario_heavy_landing_sound(m, SOUND_ACTION_TERRAIN_HEAVY_LANDING)
			    if check_fall_damage(m, ACT_HARD_BACKWARD_GROUND_KB) == 0 then
				    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE | PARTICLE_HORIZONTAL_STAR
				    set_mario_action(m, ACT_GROUND_POUND_LAND, 0)
			    end
		    end
	    end

	    set_mario_animation(m, MARIO_ANIM_START_GROUND_POUND)
	    set_anim_to_frame(m, e.animFrame)
	    if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
		    e.animFrame = m.marioObj.header.gfx.animInfo.curAnim.loopEnd
	    end
	    e.animFrame = e.animFrame + 1
	    m.actionTimer = m.actionTimer + 1
	    return
    --end
end

ACT_SQUAT_KICK_B3313 = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION | ACT_FLAG_SHORT_HITBOX | ACT_FLAG_ATTACKING)
function act_squatkick_b3313(m)
    play_sound_if_no_flag(m, SOUND_ACTION_THROW, MARIO_ACTION_SOUND_PLAYED)
    set_mario_animation(m, m.actionArg == 0 and MARIO_ANIM_START_GROUND_POUND or MARIO_ANIM_TRIPLE_JUMP_GROUND_POUND)
    if m.actionState == 0 then
        if m.actionTimer == 0 then
            --m.forwardVel = m.forwardVel + 15.0
			m.forwardVel = m.forwardVel * 1.75
        end
        m.vel.y = m.vel.y + 5
		--m.vel.y = m.vel.y + 2.5
		--m.vel.y = m.vel.y * 1.165
        if m.marioObj.header.gfx.animInfo.animFrame >= 2 then
            perform_air_step(m, 0)
        end
        if m.marioObj.header.gfx.animInfo.animFrame >= 3 then
            m.actionState = m.actionState + 1
        end
        play_mario_sound(m, SOUND_ACTION_TERRAIN_JUMP, 0)
    else
		--if m.actionTimer >= 16 then
		--	m.vel.y = m.vel.y - 1.5
		--end
        local airStepResult = perform_air_step(m, 0)

        if airStepResult == AIR_STEP_HIT_LAVA_WALL then
            lava_boost_on_wall(m)
        elseif airStepResult == AIR_STEP_HIT_WALL then
            mario_set_forward_vel(m, -8.0)
            return set_mario_action(m, ACT_SOFT_BONK, 0)
        elseif airStepResult == AIR_STEP_NONE then
            if m.actionState == 1 then
                m.flags = m.flags | MARIO_KICKING
                update_air_without_turn(m)
                if is_anim_past_end(m) then
                    m.actionState = m.actionState + 1
                end
            elseif m.actionState == 2 then
                update_air_without_turn(m)
            end
        elseif airStepResult == AIR_STEP_LANDED then
            set_mario_action(m, ACT_BUTT_SLIDE, 0)
            play_mario_landing_sound(m, SOUND_ACTION_TERRAIN_LANDING)
        end
    end
	m.actionTimer = m.actionTimer + 1
    return smlua_anim_util_set_animation(m.marioObj, "squatkick")
end

function boo_bounce(m, o, intType)
	if gPlayerSyncTable[0].B3313_Moveset then
		if intType & (INTERACT_BOUNCE_TOP | INTERACT_BOUNCE_TOP2) ~= 0 and m.pos.y > o.oPosY and m.vel.y < 0 and m.action ~= ACT_GROUND_POUND then
			if get_id_from_behavior(o.behavior) == id_bhvBoo
			or get_id_from_behavior(o.behavior) == id_bhvCourtyardBooTriplet
			or get_id_from_behavior(o.behavior) == id_bhvGhostHuntBoo
			or get_id_from_behavior(o.behavior) == id_bhvMerryGoRoundBoo
			or get_id_from_behavior(o.behavior) == id_bhvBooInCastle
			or get_id_from_behavior(o.behavior) == id_bhvBooWithCage
			or get_id_from_behavior(o.behavior) == id_bhvGhostHuntBigBoo
			or get_id_from_behavior(o.behavior) == id_bhvMerryGoRoundBigBoo
			or get_id_from_behavior(o.behavior) == id_bhvBalconyBigBoo
			then
				o.oInteractStatus = ATTACK_PUNCH + (INT_STATUS_INTERACTED | INT_STATUS_WAS_ATTACKED)
				m.vel.y = 35
				play_sound(SOUND_ACTION_HIT, m.marioObj.header.gfx.cameraToObject)
				return false
			end
		end
    end
end

local function convert_s16(num)
	num = num & 0xFFFF
	return ((num >= 0x7FFF) and (num - 0x10000) or num)
end

---@param m MarioState
local function update_custom_hang_moving(m)
	local stepResult = 0
	local nextPos = {}
	local maxSpeed = 10

	if gPlayerSyncTable[0].B3313_Moveset then
		maxSpeed = 10
	else
		maxSpeed = 4
	end
	
	m.forwardVel = m.forwardVel + 10
	if m.forwardVel > maxSpeed then
		m.forwardVel = maxSpeed
	end

	m.faceAngle.y = m.intendedYaw - approach_s32(convert_s16(m.intendedYaw - m.faceAngle.y), 0, 0x800, 0x800)

	m.slideYaw = m.faceAngle.y
	m.slideVelX = m.forwardVel * sins(m.faceAngle.y)
	m.slideVelZ = m.forwardVel * coss(m.faceAngle.y)

	m.vel.x = m.slideVelX
	m.vel.y = 0.0
	m.vel.z = m.slideVelZ

	nextPos.x = m.pos.x - m.ceil.normal.y * m.vel.x
	nextPos.z = m.pos.z - m.ceil.normal.y * m.vel.z
	nextPos.y = m.pos.y

	stepResult = perform_hanging_step(m, nextPos)

	vec3f_copy(m.marioObj.header.gfx.pos, m.pos)
	vec3s_set(m.marioObj.header.gfx.angle, 0, m.faceAngle.y, 0)
	return stepResult
end

---@param m MarioState
function act_custom_hang_moving(m)
	if m.input & INPUT_A_DOWN == 0 then
		return set_mario_action(m, ACT_FREEFALL, 0)
	end

	if m.input & INPUT_Z_PRESSED ~= 0 then
		return set_mario_action(m, ACT_GROUND_POUND, 0)
	end

	if m.ceil == nil or m.ceil.type ~= SURFACE_HANGABLE then
		return set_mario_action(m, ACT_FREEFALL, 0)
	end

	if m.actionArg & 1 ~= 0 then
		set_mario_animation(m, MARIO_ANIM_MOVE_ON_WIRE_NET_RIGHT)
	else
		set_mario_animation(m, MARIO_ANIM_MOVE_ON_WIRE_NET_LEFT)
	end

	if m.marioObj.header.gfx.animInfo.animFrame == 12 then
		play_sound(SOUND_ACTION_HANGING_STEP, m.marioObj.header.gfx.cameraToObject)
		queue_rumble_data_mario(m, 5, 30)
	end

	if is_anim_past_end(m) ~= 0 then
		m.actionArg = m.actionArg ~ 1
		if m.input & INPUT_ZERO_MOVEMENT ~= 0 then
			return set_mario_action(m, ACT_HANGING, m.actionArg)
		end
	end

	if update_custom_hang_moving(m) == 2 --[[HANG_LEFT_CEIL]] then
		set_mario_action(m, ACT_FREEFALL, 0)
	end

	return 0
end

function act_spawn_spin_airborne(m)
    if m.pos.y < m.waterLevel - 100 then
        return set_water_plunge_action(m)
    end
    m.forwardVel = 2
    m.freeze = 1
    update_air_without_turn(m)
    set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
    local airStepResult = perform_air_step(m, 0)
    if airStepResult == AIR_STEP_LANDED then
		m.actionState = m.actionState + 1
        if m.actionState == 1 then
            m.vel.y = 47.0
        end
	end
	if m.actionState == 2 then
		m.action = ACT_SPAWN_SPIN_LANDING
	end
    m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
    return false
end

local function beta_mario_before_phys_step(m)
    if (m.playerIndex ~= 0) then return end

	local slipperyFloors = (m.floor.type == SURFACE_CLASS_SLIPPERY 
    or m.floor.type == SURFACE_CLASS_VERY_SLIPPERY 
    or m.floor.type == SURFACE_HARD_SLIPPERY 
    or m.floor.type == SURFACE_HARD_VERY_SLIPPERY
    or m.floor.type == SURFACE_NOISE_SLIPPERY
    or m.floor.type == SURFACE_NOISE_VERY_SLIPPERY
    or m.floor.type == SURFACE_NOISE_VERY_SLIPPERY_73
    or m.floor.type == SURFACE_NOISE_VERY_SLIPPERY_74
    or m.floor.type == SURFACE_NO_CAM_COL_SLIPPERY
    or m.floor.type == SURFACE_NO_CAM_COL_VERY_SLIPPERY
    or m.floor.type == SURFACE_SLIPPERY
    or m.floor.type == SURFACE_VERY_SLIPPERY)	

	local hScale = 1.0
    -- friction
	if gPlayerSyncTable[0].B3313_Moveset then
    	if not slipperyFloors then
			if (m.character.type == CT_LUIGI and bluigiSlideFix) then --Fix Luigi's sliding in Character Movesets accurately
				if (m.action == ACT_BRAKING or m.action == ACT_TURNING_AROUND) then
					m.forwardVel = m.forwardVel + (hScale * 1.5)
				end
				if (m.action == ACT_MOVE_PUNCHING) then
					m.forwardVel = m.forwardVel + (hScale * 0.333)
				end
			else
				if (m.action == ACT_BRAKING or m.action == ACT_TURNING_AROUND) then
					m.forwardVel = m.forwardVel + (hScale * 2.5)
				end
				if (m.action == ACT_MOVE_PUNCHING) then
					m.forwardVel = m.forwardVel + (hScale * 0.5)
				end
			end
			if (m.controller.stickY >  0) then
				m.slideVelX = (m.slideVelX * 1.03) + (sins(m.faceAngle.y) * 0.005)
				m.slideVelZ = (m.slideVelZ * 1.03) + (coss(m.faceAngle.y) * 0.005)
			else
				m.slideVelX = m.slideVelX + (sins(m.faceAngle.y) * 0.01)
				m.slideVelZ = m.slideVelZ + (coss(m.faceAngle.y) * 0.01)
			end
    	end
	end
end

function mario_on_set_action(m)
	if (m.playerIndex ~= 0) then return end
	--This first one is literally needed so you don't get softlocked in pipes
	if m.action == ACT_EMERGE_FROM_PIPE then
		m.vel.y = m.vel.y + 10
	end
	if gPlayerSyncTable[0].B3313_Moveset then
		if m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_BACKFLIP or m.action == ACT_SIDE_FLIP or m.action == ACT_DIVE or m.action == ACT_JUMP_KICK or m.action == ACT_BACKWARD_ROLLOUT or m.action == ACT_FORWARD_ROLLOUT or m.action == ACT_WATER_JUMP then
			m.vel.y = m.vel.y + 5
		end
		if m.action == ACT_TWIRLING then
			m.vel.y = m.vel.y + 6
		end
		if m.action == ACT_WALL_KICK_AIR then
			m.vel.y = m.vel.y + 10
		end
		if m.action == ACT_LONG_JUMP then
			m.vel.y = m.vel.y + 1.5
		end
		if m.action == ACT_WALKING and m.forwardVel < 16 and (m.prevAction == ACT_IDLE or m.prevAction == ACT_PANTING or m.prevAction == ACT_DECELERATING or m.prevAction == ACT_BRAKING or m.prevAction == ACT_BRAKING_STOP)  then
			mario_set_forward_vel(m, 16)
		end
		if m.action == ACT_BRAKING then
			set_mario_action(m, ACT_IDLE, 0)
		end
		if m.action == ACT_TRIPLE_JUMP then
			set_mario_action(m, ACT_TWIRLING, 0)
			play_character_sound(m, CHAR_SOUND_YAHOO_WAHA_YIPPEE)
		end
		if m.action == ACT_BACKFLIP_LAND then
			set_mario_action(m, ACT_DOUBLE_JUMP_LAND_STOP, 0)
		end
		if m.action == ACT_GROUND_POUND then
			set_mario_action(m, ACT_GROUND_POUND_B3313, 0)
		end
		if m.action == ACT_AIR_HIT_WALL then
            set_mario_animation(m, MARIO_ANIM_START_WALLKICK)
        end
		-- Squatkick
		if enableBeeie09 then
			if m.action == ACT_SLIDE_KICK then
				set_mario_action(m, ACT_SQUAT_KICK_B3313, 0)
			end
			if m.action == ACT_GET_UP then
				set_mario_action(m, ACT_GET_UP_HOLDING, 0)
			end
		end
	end
end

local rotation = {0, 0, 0}
vec3f_set(rotation, 0, 0, 0)
fakewings = false
extendedFly = false
function mario_update(m)
    local e = gStateExtras[m.playerIndex]
	betaShadingAndTilt(m)
	--if (m.playerIndex ~= 0) then return end
	if gPlayerSyncTable[0].B3313_Moveset then
		--beta_mario_before_phys_step(m)
		if m.action == ACT_BUTT_SLIDE or m.action == ACT_BUTT_SLIDE_AIR then
			set_mario_animation(m, MARIO_ANIM_SLIDE_MOTIONLESS)
		end
		if m.action == ACT_AIR_HIT_WALL then
            m.marioObj.header.gfx.angle.y = m.faceAngle.y + 0x8000
        end
		if m.action == ACT_IDLE then
			m.actionTimer = m.actionTimer + 1
		end
		-- Delay Mario's sleeping while in dialog
		local isInDialog = get_dialog_box_state()
		if isInDialog ~= 0 and m.action == ACT_IDLE then
			m.actionTimer = 0
		end
		if m.marioBodyState.wingFlutter == 1 then
			m.vel.y = m.vel.y - 2
		end
		if m.action == ACT_PUNCHING or m.action == ACT_MOVE_PUNCHING then
			if m.actionArg == 3 then
				if m.action == ACT_PUNCHING then
					return set_mario_action(m, ACT_PUNCHING, 6)
				else
					return set_mario_action(m, ACT_MOVE_PUNCHING, 6)
				end
			end
		end
		if (m.action & ACT_FLAG_SWIMMING) == 0 then
			if m.health > 0x100 then
				if m.health < 0x800 then
					e.healTimer = e.healTimer - 1
					if e.healTimer < 0 then
						m.health = m.health + 0x100
						e.healTimer = 200
					end
				elseif m.health > 0x800 then
					e.healTimer = 200
				end
			end
		end
		--fly from cannon
		local marioHasLoggedIn = (m.action == ACT_SPAWN_NO_SPIN_AIRBORNE or m.action == ACT_SPAWN_NO_SPIN_LANDING or m.action == ACT_SPAWN_SPIN_AIRBORNE or m.action == ACT_SPAWN_SPIN_LANDING) -- Remove fakewings upon spawning into a level
		local removeFakeWings = (m.action == ACT_WALKING or m.action == ACT_IDLE or m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_DIVE_SLIDE) -- Remove fakewings on certain actions (deliberately set up to allow players to extend the time should they have a move that gets them back into the fly state)
		-- Initial launch, distinguish from regular flying/launching with a wing cap using fakewings flag
		if m.action == ACT_SHOT_FROM_CANNON and m.flags == m.flags & ~MARIO_WING_CAP then
			if (m.playerIndex == 0) then
				m.flags = m.flags | MARIO_WING_CAP
				fakewings = true
			end
			gPlayerSyncTable[m.playerIndex].switch_cap_state = true
		end
		-- Remove fakewings upon certain ground actions
		if removeFakeWings and m.flags & MARIO_WING_CAP ~= 0 and fakewings then
			m.flags = m.flags & ~MARIO_WING_CAP
			fakewings = false
			gPlayerSyncTable[m.playerIndex].switch_cap_state = false
		end
		-- Remove fakewings on warp
		if marioHasLoggedIn then 
			if (m.playerIndex == 0) then
				fakewings = false 
			end
			gPlayerSyncTable[m.playerIndex].switch_cap_state = false 
		end
		-- Keep Mario in the air after wing cap timer depletion
		if m.capTimer <= 5 and m.flags & MARIO_WING_CAP ~= 0 and m.action == ACT_FLYING and not fakewings and (m.playerIndex == 0) then
			extendedFly = true
		--else extendedFly = false
		end
		if extendedFly and m.action == ACT_FREEFALL then
			set_mario_animation(m, CHAR_ANIM_WING_CAP_FLY)
			if (m.playerIndex == 0) then
				m.flags = m.flags | MARIO_WING_CAP
				fakewings = true
				m.action = ACT_FLYING
				extendedFly = false
			end
			gPlayerSyncTable[m.playerIndex].switch_cap_state = true
		end
		-- Visually keep Mario's cap the same during the fake wing cap state
		if gPlayerSyncTable[m.playerIndex].switch_cap_state then
			if m.marioBodyState.capState == 0 or m.marioBodyState.capState ==  2 then m.marioBodyState.capState = 0
			elseif m.marioBodyState.capState == 1 or m.marioBodyState.capState == 3 then m.marioBodyState.capState = 1 end
		end
		-- 0.9+ flying
		if enableBeeie09 then
			if (m.flags & MARIO_WING_CAP ~= 0) and m.action == ACT_FLYING and (m.marioBodyState.capState ~= 0 and m.marioBodyState.capState ~= 1) then
				vec3f_set(rotation, m.faceAngle.x, 0, m.faceAngle.z)          
				m.forwardVel = 45
				m.particleFlags = m.particleFlags | PARTICLE_SPARKLES
				if (m.controller.stickY == 0) then
					m.faceAngle.x = m.faceAngle.x - 79
				end
			end
		end
	end
end

function on_pause_exit()
    m.action = ACT_SPAWN_SPIN_AIRBORNE
end

hook_event(HOOK_BEFORE_PHYS_STEP, beta_mario_before_phys_step)
hook_mario_action(ACT_GROUND_POUND_B3313, act_ground_pound_b3313, INT_GROUND_POUND_OR_TWIRL)
hook_mario_action(ACT_SQUAT_KICK_B3313, act_squatkick_b3313, INT_SLIDE_KICK)
hook_event(HOOK_ALLOW_INTERACT, boo_bounce)
hook_mario_action(ACT_SPAWN_SPIN_AIRBORNE, act_spawn_spin_airborne, INT_ANY_ATTACK)
hook_mario_action(ACT_HANG_MOVING, act_custom_hang_moving)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)
hook_event(HOOK_ON_PAUSE_EXIT, on_pause_exit)
hook_event(HOOK_MARIO_UPDATE, mario_update)

function beeieMarioAesthetics_command(msg)
    gPlayerSyncTable[0].vanillaMario = not gPlayerSyncTable[0].vanillaMario
	--play_character_sound(gMarioStates[0], CHAR_SOUND_HOOHOO)
	play_sound(SOUND_MENU_STAR_SOUND, gMarioStates[0].pos)
    return true
end

function beeieMoveset_command(msg)
	gPlayerSyncTable[0].B3313_Moveset = not gPlayerSyncTable[0].B3313_Moveset
	play_sound(SOUND_MENU_STAR_SOUND, gMarioStates[0].pos)
    return true
end

function beeieQOL_command(msg)
	enableBeeie09 = not enableBeeie09
	play_sound(SOUND_MENU_STAR_SOUND, gMarioStates[0].pos)
    return true
end

function beeieChungus_command(msg)
    chungus = not chungus
    return true
end

function bLuigiSlidePatch_command(msg)
	bluigiSlideFix = not bluigiSlideFix
	play_sound(SOUND_MENU_STAR_SOUND, gMarioStates[0].pos)
    return true
end

--hook_chat_command("bmario", ", Toggles between beta and vanilla Marios, for ''E3313 mode''.", beeieMarioAesthetics_command)
--hook_chat_command("bchungus", ", toggles the mythical Big Chungus (from 0.7 Chungus).", beeieChungus_command)
--hook_chat_command("bmoveset", "toggles the moveset from B3313's to vanilla SM64's (experimental)", bmoveset_command)
--hook_chat_command("bqol", "enables the wing cap's flight abilities and the squatkick from 0.9+ ", bqol_command)
--hook_chat_command("bluigifix", "patches Luigi's slide not losing enough momentum with Character Movesets on", bLuigiSlidePatch_command)

hook_mod_menu_checkbox("B3313 Moveset", gPlayerSyncTable[0].B3313_Moveset, beeieMoveset_command)
hook_mod_menu_checkbox("0.9+ Moves", enableBeeie09, beeieQOL_command)
hook_mod_menu_checkbox("Vanilla Mario", gPlayerSyncTable[0].vanillaMario, beeieMarioAesthetics_command)
hook_mod_menu_checkbox("Chungus Mode", chungus, beeieChungus_command)
hook_mod_menu_checkbox("Luigi Slide Fix (Character Moveset Support)", bluigiSlideFix, bLuigiSlidePatch_command)