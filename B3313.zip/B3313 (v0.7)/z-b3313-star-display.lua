-- name: B3313 Star Display
-- description: \\#ff00ff\\B\\#ff0000\\3\\#5555ff\\3\\#ffff00\\1\\#00ff00\\3\\#ff7700\\ Star Display\n\n\\#ffffff\\Tired of having to guess who got which stars? I gotcha.\n\nMod by \\#2b0013\\Floralys\\#ffffff\\.

local areas = {
    [0] = {
        [1] = {name = "Uncanny Courtyard", stars = {3,4}},
        [2] = {name = "Vanilla Basement", stars = {0,3,4}},
        [3] = {name = "Vanilla Upstairs", stars = {1,2}}
        
    },
    [1] = {
        [1] = {name = "athletic", stars = {5}},
        [2] = {name = "Crimson Hallway", stars = {3,4}},
        [3] = {name = "Goomba Hills", stars = {0,1,2,4,6}}
    },
    [2] = {
        [1] = {name = "Empty Flooded Hallway", stars = {0}},
        [2] = {name = "Lavish Lava Mountain", stars = {3,4,5,6}}
    },
    [3] = {
        [1] = {name = "Piranha's Igloo", stars = {0,5}},
        [2] = {name = "Piranha Plant Garden", stars = {4,6}},
        [3] = {name = "River Mountain", stars = {0,2,3,6}}   
    },
    [4] = {
        [1] = {name = "Checkerboard 1", stars = {3,4}},
        [2] = {name = "Jolly Roger Lagoon", stars = {0,2}},
        [3] = {name = "Orange Hall", stars = {1}},
        [4] = {name = "Test Level", stars = {6}}  
    },
    [5] = {
        [1] = {name = "King Whomp's Battle Arena", stars = {5}},
        [2] = {name = "Vanish Cap Under the Moat (Beta)", stars = {4}},
        [3] = {name = "Whomp's Kingdom", stars = {1,3,6}},
        [4] = {name = "Whomp's Prison", stars = {0,2}}
    },
    [6] = {
        [1] = {name = "Cave City", stars = {2,5}},
        [2] = {name = "Midnight Meadow", stars = {1,4}},
        [3] = {name = "Tick Tock Blocks", stars = {3,6}}   
    },
    [7] = {
        [1] = {name = "Blazing Bully Base", stars = {0,1,2,5,6}},
        [2] = {name = "Fire Bubble (B-Roll)", stars = {3}},
        [3] = {name = "Infernal Tower", stars = {4}}
    },
    [8] = {
        [1] = {name = "Desert Maze", stars = {0,1,6}},
        [2] = {name = "Eyerok's Tomb", stars = {2}},
        [3] = {name = "Shifted Sand Land", stars = {3,4,6}}
    },
    [9] = {
        [1] = {name = "Checkerboard 2", stars = {0}},
        [2] = {name = "Frosty Highlands", stars = {4,5,6}},
        [3] = {name = "Snowman's Land (Beta)", stars = {2}},
        [4] = {name = "Snow Slide (B-Roll)", stars = {0,1}}
    },
    [10] = {
        [1] = {name = "Floating Hotel", stars = {1}},
        [2] = {name = "Rainbow Ride (Beta)", stars = {4}},
        [3] = {name = "Vanish Cap within the Plexus", stars = {2,5,6}},
        [4] = {name = "Wing Cap by the Rainbow Highway", stars = {0,3,4}}
    },
    [11] = {
        [1] = {name = "Chief Chilly's Ring", stars = {4}},
        [2] = {name = "Chroma Tundra", stars = {5,6}},
        [3] = {name = "Cold, Cold Crevasse", stars = {2,3}},
        [4] = {name = "Cool, Cool Mountain (Beta)", stars = {0}},
        [5] = {name = "Snow Slide (Shoshinkai)", stars = {0}}
    },
    [12] = {
        [1] = {name = "Tall, Tall Mountain", stars = {0,2,3,4,5,6}}
    },
    [13] = {
        [1] = {name = "Bob-Omb Tower", stars = {0,2,6}},
        [2] = {name = "Grassy Highlands", stars = {4,5,6}},
        [3] = {name = "Minion Base", stars = {3,6}},
        [4] = {name = "Peach's Cell", stars = {1}},
    },
    [14] = {
        [1] = {name = "Big Boo's Fortress", stars = {0}},
        [2] = {name = "Big Boo's Haunted Forest", stars = {1,2,3,6}},
        [3] = {name = "Bowser's Floor", stars = {3}},
        [4] = {name = "Plexal Hallway", stars = {5}}
    },
    [15] = {
        [1] = {name = "Checkerboard 3", stars = {1,2}},
        [2] = {name = "Jolly Roger Bay (Beta)", stars = {0,3,4,5,6}}
    },
    [16] = {
        [1] = {name = "Creepy Cove", stars = {1,2}},
        [2] = {name = "Sunken Castle", stars = {4}},
        [3] = {name = "Tiny-Huge Island (Beta)", stars = {0}}
    },
    [17] = {
        [1] = {name = "Aquarium Limbo", stars = {0,2}},
    },
    [18] = {
        [1] = {name = "Bob-Omb Battlefield (Beta)", stars = {1,2,3}},
        [2] = {name = "Ice-Cold Warzone", stars = {3}},
        [3] = {name = "Wet-Dry World (Beta)", stars = {4,5}}
    },
    [19] = {
        [1] = {name = "Bob-Omb Village", stars = {1,2,5}},
        [2] = {name = "castle2", stars = {4}},
        [3] = {name = "Cubic Greens", stars = {0}},
        [4] = {name = "Dark Downtown", stars = {3}},
    },
    [20] = {
        [1] = {name = "Goomboss Battle", stars = {4}},
        [2] = {name = "Mountain (B-Roll)", stars = {0,1,2}},
        [3] = {name = "Tall Floating Fortress", stars = {5}},
        [4] = {name = "Whomp's Fortress (Beta)", stars = {3}}
    },
    [21] = {
        [1] = {name = "Checkerboard 4", stars = {1,2,3,4,5}},
        [2] = {name = "Eel Graveyard", stars = {0}}
    },
    [22] = {
        [1] = {name = "Battle Fort", stars = {2}},
        [2] = {name = "Big Bob-omb's Fortress", stars = {1}},
        [3] = {name = "Bob-Omb Test Field", stars = {0}}
    },
    [23] = {
        [1] = {name = "castle1", stars = {3}},
        [2] = {name = "Water Land (Shoshinkai)", stars = {0,1,2}}
    },
    [24] = {
        [1] = {name = "Dry Town", stars = {0,1}},
        [2] = {name = "Pleasant, Pleasant Falls", stars = {2,4}},
        [3] = {name = "Sky-High Pathway", stars = {5}},
        [4] = {name = "Wiggler's Forest Fortress", stars = {3}}
    },
    [25] = {
        [1] = {name = "Flooded Town", stars = {0,1,2,3}}
    }
}



local base_height = 86
local jump = 0
local page = 1
djui_hud_set_resolution(RESOLUTION_N64)
local jump_space = (djui_hud_get_screen_height() - base_height - 46.5)


local max_height = 0
for i = 0, #areas do
    for y = 1, #areas[i] do
        max_height = max_height + 1     
    end
end

screenWidth = djui_hud_get_screen_width()
screenHeight = djui_hud_get_screen_height()
halfScreenWidth = djui_hud_get_screen_width() / 2
halfScreenHeight = djui_hud_get_screen_height() / 2

--local starId = 0
local function on_interact(m, o, type)
    if type == INTERACT_STAR_OR_KEY then
        if get_id_from_behavior(o.behavior) ~= id_bhvBowserKey then
            starId = (o.oBehParams >> 24) --& 0x1F
            gStarId = (7 * gNetworkPlayers[0].currCourseNum) + starId
            djui_chat_message_create("ID: "..tostring(starId))
            djui_chat_message_create("Global ID: "..tostring(gStarId))
            --o.oBehParams = gStarId << 24
        end
    end
end

local cooldown = 5
local cooldownCounter = 0

local previousStickY = 0

-- From pause screen template, retooled for star display
local function menu_controls(options)
    local stickY = gMarioStates[0].controller.stickY

    if stickY * previousStickY <= 0 then
        cooldownCounter = cooldownCounter // 2
    end

    if cooldownCounter > 0 then
        cooldownCounter = cooldownCounter - 1
    else
        if gMarioStates[0].controller.buttonPressed & U_JPAD ~= 0 or stickY > 0.5 then
            if page >= 2 then
                jump = jump + jump_space
                page = page - 1
                play_sound(SOUND_MENU_MESSAGE_NEXT_PAGE, gMarioStates[0].marioObj.header.gfx.cameraToObject)
            else
                jump = jump - (jump_space * 14)
                page = page + 14
                play_sound(SOUND_MENU_MESSAGE_NEXT_PAGE, gMarioStates[0].marioObj.header.gfx.cameraToObject)
            end
            cooldownCounter = cooldown
        elseif gMarioStates[0].controller.buttonPressed & D_JPAD ~= 0 or stickY < -0.5 then
            if page < 15 then
                jump = jump - jump_space
                page = page + 1
                play_sound(SOUND_MENU_MESSAGE_NEXT_PAGE, gMarioStates[0].marioObj.header.gfx.cameraToObject)
            else
                jump = jump + (jump_space * 14)
                page = page - 14
                play_sound(SOUND_MENU_MESSAGE_NEXT_PAGE, gMarioStates[0].marioObj.header.gfx.cameraToObject)
            end
            cooldownCounter = cooldown
        end
    end
    previousStickY = stickY
end

local function on_hud_render()
    if not is_game_paused() then return end
    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_color(0, 0, 0, 192)
    djui_hud_render_rect(halfScreenWidth - 85, 80.5, 170, djui_hud_get_screen_height() - base_height - 20)
    djui_hud_set_color(0, 0, 0, 128)
    djui_hud_render_rect(halfScreenWidth - 83, 82.5, 166, djui_hud_get_screen_height() - base_height - 24)
    djui_hud_set_color(255, 255, 255, 255)
    local height = 0

    menu_controls()

    for i = 0, #areas do
        for y = 1, #areas[i] do
            djui_hud_set_font(FONT_TINY)
            if (20 * height) + base_height + jump >= base_height and (20 * height) + base_height + jump < 192.5 then
                djui_hud_print_text(areas[i][y].name, halfScreenWidth - 75, 20 * height + base_height + jump, 0.5)
            end
            local starFlags = save_file_get_star_flags(get_current_save_file_num() - 1, i - 1)
            djui_hud_set_font(FONT_HUD)
            for z = 1, #areas[i][y].stars do
                if starFlags & (1 << areas[i][y].stars[z]) ~= 0 then
                    if (20 * height) + base_height + jump >= base_height and (20 * height) + base_height + jump < 192.5 then
                        djui_hud_render_texture(gTextures.star, 8 * (areas[i][y].stars[z]%7) + halfScreenWidth - 75, 20 * height + 10 + base_height + jump, 0.5, 0.5)
                    end
                else
                    if (20 * height) + base_height + jump >= base_height and (20 * height) + base_height + jump < 192.5 then
                        djui_hud_print_text("@", 8 * (areas[i][y].stars[z]%7) + halfScreenWidth - 75, 20 * height + 10 + base_height + jump, 0.5)
                    end
                end
            end
            if height < max_height then
                height = height + 1
            end
        end
    end

    local starDisplayRotateTextures = {
        [0] = get_texture_info("hud_star_seg3_texture_1"),
        [1] = get_texture_info("hud_star_seg3_texture_2"),
        [2] = get_texture_info("hud_star_seg3_texture_3"),
        [3] = get_texture_info("hud_star_seg3_texture_4"),
        [4] = get_texture_info("hud_star_seg3_texture_5"),
        [5] = get_texture_info("hud_star_seg3_texture_6"),
        [6] = get_texture_info("hud_star_seg3_texture_7"),
        [7] = get_texture_info("hud_star_seg3_texture_8"),
        [8] = get_texture_info("hud_star_seg3_texture_1"),
    }
    djui_hud_set_color(255, 255, 255, 255) -- Normal
    djui_hud_render_texture(starDisplayRotateTextures[math.floor(gMarioStates[0].marioObj.oTimer / 2) % #starDisplayRotateTextures], halfScreenWidth + 20, 120, 1.5, 1.5) -- spin code by Isaac
    
    djui_hud_set_font(FONT_TINY)
    djui_hud_set_color(255, 255, 0, 255)
    djui_hud_print_text("Page:  ", halfScreenWidth + 58 - djui_hud_measure_text("Stars Collected:")*0.75*0.5, 82, 0.75)
    djui_hud_set_color(255, 255, 192, 255)
    djui_hud_print_text("       ".. page.. "/15", halfScreenWidth + 58 - djui_hud_measure_text("Stars Collected:")*0.75*0.5, 82, 0.75)
    --if page == 15 then
        djui_hud_set_color(255, 255, 0, 255)
        djui_hud_print_text("Stars Collected:", halfScreenWidth + 45 - djui_hud_measure_text("Stars Collected:")*0.75*0.5, 185, 0.75)
        djui_hud_set_color(255, 255, 192, 255)
        djui_hud_print_text(tostring(gMarioStates[0].numStars).." / 146", halfScreenWidth + 45 - djui_hud_measure_text(tostring(gMarioStates[0].numStars).." / 146")*0.75*0.5, 195, 0.75)
    --end
end

hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
--Debug stuff: hook_event(HOOK_ON_INTERACT, on_interact)