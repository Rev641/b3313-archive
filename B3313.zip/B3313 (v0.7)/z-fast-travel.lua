-- Brought to you by Floralys

local lastLobby = 1
local r = 0
local g = 0
local b = 0
local color = {r = 0, g = 0, b = 0}

local function on_hud_render()
    color = network_player_get_override_palette_color(gNetworkPlayers[gMarioStates[0].playerIndex], CAP)
    if is_game_paused() then
        djui_hud_set_resolution(RESOLUTION_N64)
        djui_hud_set_font(FONT_NORMAL)
        djui_hud_set_color(0, 0, 0, 128)
        djui_hud_print_text("PRESS A TO FAST TRAVEL", djui_hud_get_screen_width()/2 - djui_hud_measure_text("PRESS A TO FAST TRAVEL")/5 + 0.5, djui_hud_get_screen_height()/8 * 7.25 + 0.5, 0.4)
        djui_hud_render_rect(djui_hud_get_screen_width()/2 - djui_hud_measure_text("PRESS A TO FAST TRAVEL")/5 + 0.5, djui_hud_get_screen_height()/8 * 7.65 + 0.5, djui_hud_measure_text("PRESS A TO FAST TRAVEL")/2.5, 1)
        djui_hud_set_color(color.r + r, color.g + g, color.b + b, 255)
        djui_hud_print_text("PRESS A TO FAST TRAVEL", djui_hud_get_screen_width()/2 - djui_hud_measure_text("PRESS A TO FAST TRAVEL")/5, djui_hud_get_screen_height()/8 * 7.25, 0.4)
        djui_hud_render_rect(djui_hud_get_screen_width()/2 - djui_hud_measure_text("PRESS A TO FAST TRAVEL")/5, djui_hud_get_screen_height()/8 * 7.65, djui_hud_measure_text("PRESS A TO FAST TRAVEL")/2.5, 1)
        --[[djui_hud_set_color(0, 0, 0, 128)
        djui_hud_print_text("PRESS A TO FAST TRAVEL", 30, djui_hud_get_screen_height()/8 * 7.25 + 0.5, 0.4)
        djui_hud_render_rect(30, djui_hud_get_screen_height()/8 * 7.65 + 0.5, djui_hud_measure_text("PRESS A TO FAST TRAVEL")/2.5, 1)
        djui_hud_set_color(color.r + r, color.g + g, color.b + b, 255)
        djui_hud_print_text("PRESS A TO FAST TRAVEL", 30, djui_hud_get_screen_height()/8 * 7.25, 0.4)
        djui_hud_render_rect(30, djui_hud_get_screen_height()/8 * 7.65, djui_hud_measure_text("PRESS A TO FAST TRAVEL")/2.5, 1)]]
    end

    if color.r + r >= 255 and color.g + g >= 255 and color.b + b >= 255 then
        r = 255 - color.r
        g = 255 - color.g
        b = 255 - color.b
        switch = true
    elseif r <= 0 and g <= 0 and b <= 0 then
        r = 0
        g = 0
        b = 0
        switch = false
    end

    if switch then
        if r > 0 then
            r = r - 5
        end
        if g > 0 then
            g = g - 5
        end
        if b > 0 then
            b = b - 5
        end
    elseif not switch then
        r = r + (255 - color.r)/75
        g = g + (255 - color.g)/75
        b = b + (255 - color.b)/75
    end

    if color.r + r > 255 then
        r = 255 - color.r
    end
    if color.g + g > 255 then
        g = 255 - color.g
    end
    if color.b + b > 255 then
        b = 255 - color.b
    end
end

---@param m MarioState
local function mario_update(m)
    if gNetworkPlayers[m.playerIndex].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[m.playerIndex].currAreaIndex == 4 then
        lastLobby = 1
    elseif gNetworkPlayers[m.playerIndex].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[m.playerIndex].currAreaIndex == 3 then
        lastLobby = 2
    elseif gNetworkPlayers[m.playerIndex].currLevelNum == LEVEL_CASTLE_GROUNDS and gNetworkPlayers[m.playerIndex].currAreaIndex == 2 then
        lastLobby = 3
    end

    if is_game_paused() then
        if m.playerIndex ~= 0 then return end
        if (m.controller.buttonPressed & A_BUTTON ~= 0) then
            if lastLobby == 1 then
                warp_to_level(16, 3, 1)
            elseif lastLobby == 2 then
                warp_to_level(16, 2, 1)
            elseif lastLobby == 3 then
                warp_to_level(16, 4, 1)
            end
            enable_background_sound()
        end
    end
end

hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_MARIO_UPDATE, mario_update)